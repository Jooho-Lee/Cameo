function Save_Survey() {
	var age = document.surveyCheck['age'].options[document.surveyCheck['age'].selectedIndex].value;
	var sex = $("input:radio[name=sex]:checked").val();
	var location = document.surveyCheck['location'].options[document.surveyCheck['location'].selectedIndex].text;
	var marry = $("input:radio[name=marry]:checked").val();
	var child = $("input:radio[name=child]:checked").val();
	var annualfee = document.getElementById("annualfee").value;
	var income = document.getElementById("income").value;
	var saving = document.getElementById("saving").value;
	var cardRate = document.getElementById("cardRate").value;
	var prefer1 = document.surveyCheck['prefer1'].options[document.surveyCheck['prefer1'].selectedIndex].value;
	var prefer2 = document.surveyCheck['prefer2'].options[document.surveyCheck['prefer2'].selectedIndex].value;
	var prefer3 = document.surveyCheck['prefer3'].options[document.surveyCheck['prefer3'].selectedIndex].value;
	var prefer4 = document.surveyCheck['prefer4'].options[document.surveyCheck['prefer4'].selectedIndex].value;
	if (age == "연령대 선택") {
		alert("연령대를 입력해 주세요.");
	} else {
		if (sex == null) {
			alert("성별을 선택해 주세요.");
		} else {
			if (location == "지역선택") {
				alert("지역을 선택해 주세요.");
			} else {
				if (marry == null) {
					alert("결혼유무를 선택해 주세요.");
				} else {
					if (child == null) {
						alert("자녀 유무를 선택해 주세요.");
					} else {
						if (income == "") {
							alert("월 수입을 입력해 주세요.");
						} else {
							if(saving==""){
								alert("월 저축을 입력해 주세요.");
							}else{
								if (cardRate == "") {
									alert("카드 이용률을 입력해 주세요.");
								} else {
									if (prefer1 == "" && prefer2 == ""
										&& prefer3 == "" && prefer4 == "") {
										alert("주요소비를 입력해주세요!(1가지 이상)");
									} else if ((prefer1 == "" || prefer2 == "" || prefer3 == "")
											&& prefer4 != "") {
										alert("상위순위부터 입력해 주세요.");
									} else if ((prefer1 == "" || prefer2 == "")
											&& prefer3 != "") {
										alert("순서대로 입력해 주세요!");
									} else if (prefer1 == "" && prefer2 != "") {
										alert("순서대로 입력해 주세요!");
									} else {
										if ((prefer1 == prefer2
												|| prefer1 == prefer3
												|| prefer1 == prefer4
												|| prefer2 == prefer3
												|| prefer2 == prefer4
												|| prefer3 == prefer4) && (prefer2 !="" || prefer3 !="" || prefer4 !="")){
											alert("중복선택은 불가능 합니다.");
										}else{
											document.surveyCheck.action="Survey_Input.sp";
											document.surveyCheck.method="GET";
											document.surveyCheck.submit();
										}
							}
								}
							}
						}
					}
				}
			}
		}
	}
}
function change_Survey() {
	var age = document.change_su['age'].options[document.change_su['age'].selectedIndex].value;
	var sex = $("input:radio[name=sex]:checked").val();
	var location = document.change_su['location'].options[document.change_su['location'].selectedIndex].text;
	var marry = $("input:radio[name=marry]:checked").val();
	var child = $("input:radio[name=child]:checked").val();
	var annualfee = document.getElementById("annualfee").value;
	var income = document.getElementById("income").value;
	var saving = document.getElementById("saving").value;
	var cardRate = document.getElementById("cardRate").value;
	var prefer1 = document.change_su['prefer1'].options[document.change_su['prefer1'].selectedIndex].value;
	var prefer2 = document.change_su['prefer2'].options[document.change_su['prefer2'].selectedIndex].value;
	var prefer3 = document.change_su['prefer3'].options[document.change_su['prefer3'].selectedIndex].value;
	var prefer4 = document.change_su['prefer4'].options[document.change_su['prefer4'].selectedIndex].value;
	if (age == "연령대 선택") {
		alert("연령대를 입력해 주세요.");
	} else {
		if (sex == null) {
			alert("성별을 선택해 주세요.");
		} else {
			if (location == "지역선택") {
				alert("지역을 선택해 주세요.");
			} else {
				if (marry == null) {
					alert("결혼유무를 선택해 주세요.");
				} else {
					if (child == null) {
						alert("자녀 유무를 선택해 주세요.");
					} else {
						if (income == "") {
							alert("월 수입을 입력해 주세요.");
						} else {
							if(saving==""){
								alert("월 저축을 입력해 주세요.");
							}else{
								if (cardRate == "") {
									alert("카드 이용률을 입력해 주세요.");
								} else {
									if (prefer1 == "" && prefer2 == ""
										&& prefer3 == "" && prefer4 == "") {
										alert("주요소비를 입력해주세요!(1가지 이상)");
									} else if ((prefer1 == "" || prefer2 == "" || prefer3 == "")
											&& prefer4 != "") {
										alert("상위순위부터 입력해 주세요.");
									} else if ((prefer1 == "" || prefer2 == "")
											&& prefer3 != "") {
										alert("순서대로 입력해 주세요!");
									} else if (prefer1 == "" && prefer2 != "") {
										alert("순서대로 입력해 주세요!");
									} else {
										if ((prefer1 == prefer2
												|| prefer1 == prefer3
												|| prefer1 == prefer4
												|| prefer2 == prefer3
												|| prefer2 == prefer4
												|| prefer3 == prefer4) && prefer3 !=""){
											alert("중복선택은 불가능 합니다.");
										}else{
											document.change_su.action="/cameo/Survey_Input.sp";
											document.change_su.method="GET";
											document.change_su.submit();
										}
							}
								}
							}
						}
					}
				}
			}
		}
	}
}
function Ben_Survey(){
	var cardtype = document.surveyBene['cardtype'].options[document.surveyBene['cardtype'].selectedIndex].value;
	var bentype = document.surveyBene['bentype'].options[document.surveyBene['bentype'].selectedIndex].value;
	var benefit1 = document.surveyBene['benefit1'].options[document.surveyBene['benefit1'].selectedIndex].value;
	var benefit2 = document.surveyBene['benefit2'].options[document.surveyBene['benefit2'].selectedIndex].value;
	if(cardtype == "카드 유형"){
		alert("카드 유형을 선택해 주세요!");
	}else{
		if(bentype == "혜택 유형"){
		alert("혜택 유형을 선택해 주세요!");
		}else{
			if(benefit1 == ""){
				alert("선호 혜택 1을 선택해 주세요!");
			}else{
				if(benefit2==""){
					alert("선호 혜택 2를 선택해 주세요!");
				}else{
					if(benefit1 == benefit2){
						alert("중복 선택은 불가능 합니다!");
					}else{
						document.surveyBene.action="/cameo/SuggestSaving.sp";
						document.surveyBene.method="POST";
						document.surveyBene.submit();
					}
				}
			}
		}
	}
	
}