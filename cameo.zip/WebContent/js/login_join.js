//db 왓다리 갓다리.
var httpRequest;
function createXMLHttpRequest(){
	if(window.XMLHttpRequest){
		httpRequest = new XMLHttpRequest();
	}else{
		return null;
	}
}
//id ajax통신
function checkId(){
	if(httpRequest.readyState==4){
		if(httpRequest.status ==200){
			document.getElementById('idCheck').innerHTML = 
				httpRequest.responseText;
		}else{
			alert("실패 : " + httpRequest.statusText);
		}
	}
}
//id check
function idCheck(){
	createXMLHttpRequest();
	var id = document.getElementById("inputID").value;
	var url = "http://192.168.0.24:8787/cameo/JoinIdCheck.sp?aa="+id;
	httpRequest.onreadystatechange = checkId;
	httpRequest.open("GET",url,true);
	httpRequest.send();
	
}
//pwd check
function pwCheck(){
	var pwd1 = document.getElementById("pwInsert").value;
	var pwd2 = document.getElementById("pwdCheck").value;
	if(pwd1 == pwd2){
		document.getElementById("pwdResult").innerHTML=
			"<span class='sp1'>사용가능합니다.</span>";
	}else{
		document.getElementById("pwdResult").innerHTML=
			"<span class='sp2'>같은 비밀번호를 입력하세요!</span>";
	}
}
//이미지 로더
function uploadImg(input){
    if (input.files && input.files[0]) {
        var reader = new FileReader();
        reader.onload = function (e) {
            $('#view').attr('src', e.target.result);
        }
        reader.readAsDataURL(input.files[0]);
    }
}
function JoinMember(){
	var id = document.getElementById("inputID").value;
	var idCheck = $("#idCheck").text();
	var pwd = document.getElementById("pwInsert");
	var pwdCheck = $("#pwdResult").text();
	var name = document.getElementById("name").value;
	var birth = document.getElementById("mydate").value;
	var sex =$("input:radio[name=sex]:checked").val();
	var mobile = document.getElementById("mobile").value;
	var email = document.getElementById("email").value;
	if(idCheck == "사용중인 ID입니다."){
		alert("사용중인 ID입니다.");
	}else{
		if(pwdCheck == "같은 비밀번호를 입력하세요!"){
			alert("비밀번호가 틀립니다.");
		}else{
			if(name == ""){
				alert("이름을 입력해 주세요.");
			}else{
				if(sex == null){
					alert("성별을 체크해 주세요.");
				}else{
					if(birth == ""){
						alert("생년월일을 입력해 주세요");
					}else{
						if(mobile == ""){
							alert("핸드폰 번호를 입력해 주세요.");
						}else{
							if(email == ""){
								alert("이메일 주소를 입력해 주세요.");
							}else{
								document.joinForm.action="./JoinMember.sp";
								document.joinForm.method="POST";
								document.joinForm.submit();
								alert("회원가입완료! 로그인해 주세요!");
							}
						}
					}
				}
			}
		}
	}
}

function LoginMember(){
	
	createXMLHttpRequest();
	var id = document.getElementById("inputId").value;
	var pwd = document.getElementById("inputPassword").value;
	if(id == null){
		alert("ID를 입력해주세요.");
	}else if(pwd == null){
		alert("비밀번호를 입력하세요.");
	}else{
		var url = "http://192.168.0.24:8787/cameo/LoginCheck.sp?id="+id+"&pwd="+pwd;
		httpRequest.onreadystatechange = LoginCheck;
		httpRequest.open("GET",url,true);
		httpRequest.send(null);
	}
}
function LoginCheck(){
	if(httpRequest.readyState==4){
		if(httpRequest.status ==200){
			var res = httpRequest.responseText;
			if(res !="not correct!"){
				alert("WelCome Cameo!");
				location.replace("./NoticeToMain.sp");
			}else{
				alert(res);
				location.replace("index.jsp");
			}
		}else{
			alert("실패 : " + httpRequest.statusText);
		}
	}
}