var root = "/cameo";

function getBoardType(){
	document.location.href= root+"/e_board.sp?act=btype";

}

function goWrite(){
	document.moveform.act.value="mvnew";
	document.moveform.action = root + "/e_board.sp";
	document.moveform.submit();
}

function writeArticle(){
	var text = document.writeForm.board_Text.value;
	if(text == ""){
		alert("please, input the Text!");
		return;
	}else if(getStringLength(text) >150){
		alert("can't write words over 150byte");
	}else{
		document.writeForm.key.value = "";
		document.writeForm.word.value = "";
		document.writeForm.action = root + "/e_board.sp";
		document.writeForm.submit();
	}
}

function getStringLength(str)
{
	var retCode = 0;
	var strLength = 0;

	for (i = 0; i < str.length; i++)
		{
			var code = str.charCodeAt(i)
			var ch = str.substr(i,1).toUpperCase()

			code = parseInt(code)

			if ((ch < "0" || ch > "9") && (ch < "A" || ch > "Z") && ((code > 255) || (code < 0)))
				strLength = strLength + 2;
			else
				strLength = strLength + 1;
		}
	return strLength;
}


function getByteLength(s, b, i, c){
	for(b=i=0; c=s.charCodeAt(i++); b+=c>>11?3:c>>7?2:1);
	return b;
}


function goList(btype, pg){
	document.moveform.act.value="list";
	document.moveform.btype.value=btype;
	document.moveform.pg.value=pg;
	document.moveform.action = root + "/e_board.sp";
	document.moveform.submit();
}

function goNewList(){
	document.moveform.act.value="list";
	document.moveform.pg.value=1;
	document.moveform.key.value="";
	document.moveform.word.value="";
	document.moveform.action = root + "/e_board.sp";
	document.moveform.submit();
}

function goMyList(id){
	document.moveform.act.value="list";
	document.moveform.pg.value=1;
	document.moveform.key.value="user_ID";
	document.moveform.word.value=id;
	document.moveform.action = root + "/e_board.sp";
	document.moveform.submit();
}

function goBbsSearch(){
	document.searchForm.action = root + "/e_board.sp";
	document.searchForm.submit();
}

function check_reply(seq){
	document.moveform.act.value="mvreply";
	document.moveform.board_Seq.value=seq;
	document.moveform.action = root + "/e_board.sp";
	document.moveform.submit();
}

function check_modify(seq){
	document.moveform.act.value="modify";
	document.moveform.board_Seq.value=seq;
	document.moveform.action = root + "/e_board.sp";
	document.moveform.submit();
}

function modifyArticle(seq){
	if(document.writeForm.board_Text.value == ""){
		alert("please, input the Text!");
		return;

	}else{

		document.writeForm.board_Seq.value=seq;
		document.writeForm.key.value = "";
		document.writeForm.word.value = "";
		document.writeForm.action = root + "/e_board.sp";
		document.writeForm.submit();
		
	}

}

function check_delete(seq){
	document.moveform.act.value="delete";
	document.moveform.board_Seq.value=seq;
	document.moveform.action = root + "/e_board.sp";
	document.moveform.submit();

}

