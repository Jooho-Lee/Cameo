var root = "/cameo";

function goWrite(){
	document.moveform.act.value="mvnew";
	document.moveform.action = root + "/board.sp";
	document.moveform.submit();
}

function writeArticle(){
	if(document.writeForm.subject.value == ""){
		alert("please, input the subject!");
		return;
	}else{
		document.writeForm.content.value = alice.getContent();
		document.writeForm.key.value = "";
		document.writeForm.word.value = "";
		document.writeForm.action = root + "/board.sp";
		document.writeForm.submit();
	}
}

function viewArticle(seq){
	if(seq == 0){
		alert("viewArticle에러");
		return;
	}else{
		document.moveform.act.value="view";
		document.moveform.seq.value=seq;
		document.moveform.action = root + "/board.sp";
		document.moveform.submit();
	}
}

function goList(pg){
	document.moveform.act.value="list";
	document.moveform.pg.value=pg;
	document.moveform.action = root + "/board.sp";
	document.moveform.submit();
}

function goNewList(){
	document.moveform.act.value="list";
	document.moveform.pg.value=1;
	document.moveform.key.value="";
	document.moveform.word.value="";
	document.moveform.action = root + "/board.sp";
	document.moveform.submit();
}

function goMyList(id){
	document.moveform.act.value="list";
	document.moveform.pg.value=1;
	document.moveform.key.value="id";
	document.moveform.word.value=id;
	document.moveform.action = root + "/board.sp";
	document.moveform.submit();
}

function goBbsSearch(){
	document.searchForm.action = root + "/board.sp";
	document.searchForm.submit();
}

function check_reply(seq){
	document.moveform.act.value="mvreply";
	document.moveform.seq.value=seq;
	document.moveform.action = root + "/board.sp";
	document.moveform.submit();
}

function check_modify(seq){
	document.moveform.act.value="modify";
	document.moveform.seq.value=seq;
	document.moveform.action = root + "/board.sp";
	document.moveform.submit();
}

function modifyArticle(seq){
	if(document.writeForm.subject.value == ""){
		console.log(document.writefor.subject.value);
		alert("modify please, input the subject!");
		return;
	}else if(alice.getContent() == ""){
		alert("modify please, input the contents!");
		return;
	}else{
		document.writeForm.content.value = alice.getContent();
		document.moveform.seq.value=seq;
		document.writeForm.key.value = "";
		document.writeForm.word.value = "";
		document.writeForm.action = root + "/board.sp";
		document.writeForm.submit();
		
	}
	

}

function check_delete(seq){
	document.moveform.act.value="delete";
	document.moveform.seq.value=seq;
	document.moveform.action = root + "/board.sp";
	document.moveform.submit();
}

