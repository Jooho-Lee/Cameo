


/*회원가입이랑 동일한 비밀번호 체크*/
function pwCheck(){
	var pwd1 = document.getElementById("pwInsert").value;
	var pwd2 = document.getElementById("pwdCheck").value;
	if(pwd1 == pwd2){
		document.getElementById("pwdResult").innerHTML=
			"<span class='sp1'>사용가능합니다.</span>";
	}else{
		document.getElementById("pwdResult").innerHTML=
			"<span class='sp2'>같은 비밀번호를 입력하세요!</span>";
	}
}

/*마찬간지로 이미지 업로더*/
function uploadImg(input) {
	if (input.files && input.files[0]) {
		var reader = new FileReader();
		reader.onload = function(e) {
			$('#view').attr('src', e.target.result);
		}
		reader.readAsDataURL(input.files[0]);
	}	
}

function updateCheck(){
	var currimage = document.getElementById("CurrImage").value;
	var image = document.getElementById("exampleInputFile").value;
	var pwd = document.getElementById("pwInsert");
	var pwdCheck = $("#pwdResult").text();
	var name = document.getElementById("name").value;
	var birth = document.getElementById("mydate").value;
	var sex =$("input:radio[name=sex]:checked").val();
	var mobile = document.getElementById("mobile").value;
	var email = document.getElementById("email").value;
	alert(currimage);
	alert(image);
	if(image == ""){
		alert("이미지를 등록하세요.");
	}else{
		if(pwdCheck == "같은 비밀번호를 입력하세요!"){
			alert("비밀번호가 틀립니다.");
		}else{
			if(name == ""){
				alert("이름을 입력해 주세요.");
			}else{
				if(sex == null){
					alert("성별을 체크해 주세요.");
				}else{
					if(birth == ""){
						alert("생년월일을 입력해 주세요");
					}else{
						if(mobile == ""){
							alert("핸드폰 번호를 입력해 주세요.");
						}else{
							if(email == ""){
								alert("이메일 주소를 입력해 주세요.");
							}else{
								document.joinForm.action="./UserUpdate.sp";
								document.joinForm.method="POST";
								document.joinForm.submit();
							}
						}
					}
				}
			}
		}
	}
}