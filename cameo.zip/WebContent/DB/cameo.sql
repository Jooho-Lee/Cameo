insert into boardtype (btype, cardname, cardimg)
values (boardtype_seq.nextval, 'SK������ The you', 'https://www.shinhancard.com/_ICSFiles/afieldfile/2012/01/03/img)you.jpg');

insert into boardtype (btype, cardname, cardimg)
values (boardtype_seq.nextval, '������Ϲ�ũ Oil Saving 100', 'https://www.shinhancard.com/_ICSFiles/afieldfile/2012/03/19/card_hyundai_s.jpg');
select * from user_info;
insert into boardtype (btype, cardname, cardimg)
values (boardtype_seq.nextval, 'S-Oil ���ʽ� +100', 'https://www.shinhancard.com/_ICSFiles/afieldfile/2011/12/29/img_so_1.jpg');

[Sequence]
drop sequence su_seq;
drop sequence q_seq;
drop sequence NOTICE_SEQ;
drop sequence card_seq;
drop sequence benefit_seq;
drop sequence boardtype_seq;
drop sequence board_seq;

CREATE SEQUENCE  SU_SEQ 
     START WITH 1  
     INCREMENT BY 1
     NOMAXVALUE
     NOMINVALUE
     NOCACHE;

CREATE SEQUENCE  Q_SEQ 
     START WITH 1  
     INCREMENT BY 1
     NOMAXVALUE
     NOMINVALUE
     NOCACHE;

CREATE SEQUENCE  NOTICE_SEQ 
     START WITH 1  
     INCREMENT BY 1
     NOMAXVALUE
     NOMINVALUE
     NOCACHE;

CREATE SEQUENCE  CARD_SEQ 
     START WITH 155 
     INCREMENT BY 1
     NOMAXVALUE
     NOMINVALUE
     NOCACHE;

CREATE SEQUENCE  BENEFIT_SEQ 
     START WITH 358
     INCREMENT BY 1
     NOMAXVALUE
     NOMINVALUE
     NOCACHE;

create sequence boardtype_seq
    start with 1
    increment by 1
    NOMAXVALUE
    NOMINVALUE
    NOCACHE;

create sequence board_seq
    start with 1
    increment by 1
    NOMAXVALUE
    NOMINVALUE
    NOCACHE; 
    
[Table]

drop table user_info;
drop table survey;
drop table qna;
drop table notice;
drop table card;
drop table benefit;
drop table board;
drop table boardtype;


CREATE TABLE  "CARD" 
   (    "CARD_NAME" VARCHAR2(100) NOT NULL ENABLE, 
        "CARD_SEQ" NUMBER NOT NULL ENABLE, 
        "CARD_TYPE" VARCHAR2(4) NOT NULL ENABLE, 
        "CARD_CORP" VARCHAR2(10) NOT NULL ENABLE, 
        "CARD_IMAGE" VARCHAR2(100) NOT NULL ENABLE, 
        "ANNUALFEE" NUMBER, 
         CONSTRAINT "PK_CARD" PRIMARY KEY ("CARD_SEQ") ENABLE
   )

CREATE TABLE  "BENEFIT" 
   (    "CARD_SEQ" NUMBER NOT NULL ENABLE, 
        "BEN_SEQ" NUMBER NOT NULL ENABLE, 
        "USAGE_RESULT" NUMBER, 
        "BEN1" VARCHAR2(10), 
        "BEN2" VARCHAR2(10), 
        "BEN3" VARCHAR2(10), 
        "BEN4" VARCHAR2(10), 
        "BEN5" VARCHAR2(10), 
        "BEN6" VARCHAR2(10), 
        "BEN7" VARCHAR2(10), 
        "BEN8" VARCHAR2(10), 
        "BEN9" VARCHAR2(10), 
        "BEN10" VARCHAR2(10), 
        "BEN11" VARCHAR2(10), 
        "BEN12" VARCHAR2(10), 
        "BEN13" VARCHAR2(10), 
        "BEN14" VARCHAR2(10), 
        "BEN15" VARCHAR2(10), 
        "BEN16" VARCHAR2(10), 
        "BEN17" VARCHAR2(10), 
        "BEN18" VARCHAR2(10), 
        "BEN19" VARCHAR2(10), 
        "BEN20" VARCHAR2(10), 
         CONSTRAINT "PK_BENEFIT" PRIMARY KEY ("CARD_SEQ", "BEN_SEQ") ENABLE, 
         CONSTRAINT "FK_CARD_TO_BENEFIT" FOREIGN KEY ("CARD_SEQ")
          REFERENCES  "CARD" ("CARD_SEQ") ENABLE
   )


CREATE TABLE  "BOARDTYPE" 
   (    "BTYPE" NUMBER(5,0), 
        "CARDNAME" VARCHAR2(200), 
        "CARDIMG" VARCHAR2(200), 
         CONSTRAINT "BOARDTYPE_TYPE_PK" PRIMARY KEY ("BTYPE") ENABLE
   )


CREATE TABLE  "BOARD" 
   (    "USER_ID" VARCHAR2(16), 
        "BOARD_SEQ" NUMBER, 
        "BTYPE" NUMBER(2,0), 
        "BOARD_TEXT" VARCHAR2(250), 
        "BOARD_A_DATE" DATE DEFAULT sysdate, 
        "BOARD_REF" NUMBER, 
        "BOARD_STEP" NUMBER(4,0) DEFAULT 0, 
        "BOARD_LEV" NUMBER(4,0) DEFAULT 0, 
        "BOARD_PSEQ" NUMBER, 
        "BOARD_REPLY" NUMBER(4,0), 
         CONSTRAINT "BOARD_TYPE_FK" FOREIGN KEY ("BTYPE")
          REFERENCES  "BOARDTYPE" ("BTYPE") ENABLE
   )


CREATE TABLE  "NOTICE" 
   (    "NOTICE_SEQ" NUMBER NOT NULL ENABLE, 
        "NOTICE_TEXT" VARCHAR2(1000) NOT NULL ENABLE, 
        "NOTICE_C_DATE" DATE NOT NULL ENABLE, 
        "NOTICE_A_DATE" DATE NOT NULL ENABLE, 
         CONSTRAINT "PK_NOTICE" PRIMARY KEY ("NOTICE_SEQ") ENABLE
   )
   
CREATE TABLE  "USER_INFO" 
   (    "USER_ID" VARCHAR2(20) NOT NULL ENABLE, 
        "USER_NAME" VARCHAR2(10) NOT NULL ENABLE, 
        "USER_IMAGE" VARCHAR2(20) NOT NULL ENABLE, 
        "USER_PW" VARCHAR2(20) NOT NULL ENABLE, 
        "USER_GENDER" VARCHAR2(2) NOT NULL ENABLE, 
        "USER_BIRTH" DATE NOT NULL ENABLE, 
        "USER_TEL" VARCHAR2(13), 
        "USER_EMAIL" VARCHAR2(20), 
        "ACCESS_COUNT" NUMBER(10,0), 
        "LAST_ACCESS" DATE, 
        "USE_YN" VARCHAR2(5) DEFAULT 'Y', 
         CONSTRAINT "PK_USER_INFO" PRIMARY KEY ("USER_ID") ENABLE
   )

CREATE TABLE  "QNA" 
   (    "USER_ID" VARCHAR2(16), 
        "Q_SEQ" NUMBER, 
        "SUBJECT" VARCHAR2(30), 
        "CONTEXT" VARCHAR2(4000), 
        "HIT_CNT" NUMBER(4,0), 
        "REF" NUMBER, 
        "STEP" NUMBER(4,0) DEFAULT 0, 
        "LEV" NUMBER(4,0) DEFAULT 0, 
        "P_SEQ" NUMBER, 
        "RE_CNT" NUMBER(4,0), 
        "LOGDATE" DATE DEFAULT sysdate, 
         CONSTRAINT "QNA_SEQ_PK" PRIMARY KEY ("Q_SEQ") ENABLE, 
         CONSTRAINT "USER_INFO_FK" FOREIGN KEY ("USER_ID")
          REFERENCES  "USER_INFO" ("USER_ID") ENABLE
   )

  CREATE TABLE  "SURVEY" 
   (    "USER_ID" VARCHAR2(20) NOT NULL ENABLE, 
        "COL" NUMBER NOT NULL ENABLE, 
        "FEELIMIT" VARCHAR2(10) NOT NULL ENABLE, 
        "INCOME" VARCHAR2(10) NOT NULL ENABLE, 
        "SAVING" VARCHAR2(10) NOT NULL ENABLE, 
        "CARDRATE" NUMBER NOT NULL ENABLE, 
        "PREFER1" VARCHAR2(10), 
        "PREFER2" VARCHAR2(10), 
        "PREFER3" VARCHAR2(10), 
        "PREFER4" VARCHAR2(10), 
        "MARRIAGE" VARCHAR2(10), 
        "CHILD" VARCHAR2(10), 
        "LOCATION" VARCHAR2(50), 
        "SURVEYDATE" DATE NOT NULL ENABLE, 
        "GENDER" VARCHAR2(10) NOT NULL ENABLE, 
        "AGEGROUP" VARCHAR2(4) NOT NULL ENABLE, 
         CONSTRAINT "PK_SURVEY" PRIMARY KEY ("USER_ID", "COL") ENABLE, 
         CONSTRAINT "FK_USER_INFO_TO_SURVEY" FOREIGN KEY ("USER_ID")
          REFERENCES  "USER_INFO" ("USER_ID") ENABLE
   )


select * from survey;
