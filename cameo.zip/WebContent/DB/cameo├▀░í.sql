drop table board;
drop sequence board_seq;
drop table boardtype;
drop sequence boardtype_seq;

create table Board
(
  User_ID varchar2(16),
  Board_Seq number,
  btype number(5),
  Board_Text varchar2(250),
  Board_A_Date date default sysdate,
  Board_Ref number,
  Board_Step number(4) default 0,
  Board_Lev number(4) default 0, 
  Board_Pseq number,
  Board_Reply number(4),

  constraint board_type_fk foreign key (btype) references card (card_seq)
);

create sequence board_seq start with 1 increment by 1;

