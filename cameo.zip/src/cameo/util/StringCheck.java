package cameo.util;

public class StringCheck {
	public static String nullToBlank(String tmp){
		return tmp == null ? "" : tmp;
	}
}
