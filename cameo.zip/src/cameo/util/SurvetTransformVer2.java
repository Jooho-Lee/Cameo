package cameo.util;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

public class SurvetTransformVer2 {
   

public String location(String location) {
      if (location.equals("1")) {
         location = "Seoul";
      } else if (location.equals("2")) {
         location = "Gyeonggi";
      } else if (location.equals("3")) {
         location = "Incheon";
      } else if (location.equals("4")) {
         location = "Chung Nam";
      } else if (location.equals("5")) {
         location = "Chung Buk";
      } else if (location.equals("6")) {
         location = "Jeon Nam";
      } else if (location.equals("7")) {
         location = "Jeon Buk";
      } else if (location.equals("8")) {
         location = "Gyeong Nam";
      } else if (location.equals("9")) {
         location = "Gyeong Buk";
      } else if (location.equals("10")) {
         location = "Gangwon";
      } else if (location.equals("11")) {
         location = "Jeju";
      } else if (location.equals("12")) {
         location = "Ulleung/Dok do";
      }
      return location;
   }

   public String child(String child){
      if(child.equals("1")){
         child = "Have";
      }else{
         child = "Not";
      }
      return child;
   }
   public String marriage(String marriage){
      if(marriage.equals("1")){
         marriage = "Done";
      }else{
         marriage = "Not";
      }
      return marriage;
   }

   public String benefit(String prefer) {
      if (prefer.equals("ben1")) {
         prefer = "Gas";
      } else if (prefer.equals("ben2")) {
         prefer = "Dine out";
      } else if (prefer.equals("ben3")) {
         prefer = "Mart";
      } else if (prefer.equals("ben4")) {
         prefer = "Shopping";
      } else if (prefer.equals("ben5")) {
         prefer = "Beauty";
      } else if (prefer.equals("ben6")) {
         prefer = "Cafe";
      } else if (prefer.equals("ben7")) {
         prefer = "Bakery";
      } else if (prefer.equals("ben8")) {
         prefer = "Movie";
      } else if (prefer.equals("ben9")) {
         prefer = "Traffic";
      } else if (prefer.equals("ben10")) {
         prefer = "Telecom";
      } else if (prefer.equals("ben11")) {
         prefer = "Leisure";
      } else if (prefer.equals("ben12")) {
         prefer = "Convenience Store";
      } else if (prefer.equals("ben13")) {
         prefer = "Education";
      } else if (prefer.equals("ben14")) {
         prefer = "Cultural Life";
      } else if (prefer.equals("ben15")) {
         prefer = "Book";
      } else if (prefer.equals("ben16")) {
         prefer = "Game";
      } else if (prefer.equals("ben17")) {
         prefer = "Music";
      } else if (prefer.equals("ben18")) {
         prefer = "Travel";
      } else if (prefer.equals("ben19")) {
         prefer = "Medical";
      } else if (prefer.equals("ben20")) {
         prefer = "Overseas";
      }
      return prefer;
   }

   public HashMap Transform_Text(HashMap hm) {

     String child = null;
      String marriage = null;
      String prefer1 = null;
      String prefer2 = null;
      String prefer3 = null;
      String prefer4 = null;
      String location = null;
      String gender = null;

      HashMap res = new HashMap();
      SurvetTransformVer2 stf = new SurvetTransformVer2();

      String hash_key = null;
      Iterator entrys = hm.entrySet().iterator();
      while (entrys.hasNext()) {
         Map.Entry mEntry = (Map.Entry) entrys.next();
         hash_key = (String)mEntry.getKey();
        
      

        /* child = (String) hm.get("CHILD");
         marriage = (String)hm.get("MARRIAGE");
         System.out.println("����� ..." + (String)hm.get("MARRIAGE"));
         prefer1 = (String) hm.get("PREFER1");
         prefer2 = (String) hm.get("PREFER2");
         prefer3 = (String) hm.get("PREFER3");
         prefer4 = (String) hm.get("PREFER4");
         location = (String) hm.get("LOCATION");
         gender = (String)hm.get("GENDER");*/

       if (hash_key.equals("CHILD")) {
          child = (String) hm.get("CHILD");
       } else if (hash_key.equals("MARRIAGE")) {
          marriage = (String)hm.get("MARRIAGE");
       } else {
          prefer1 = (String) hm.get("PREFER1");
          prefer2 = (String) hm.get("PREFER2");
          prefer3 = (String) hm.get("PREFER3");
          prefer4 = (String) hm.get("PREFER4");
          location = (String) hm.get("LOCATION");
          gender = (String)hm.get("GENDER");
       }
      }

      if (prefer1 != null || prefer2 != null || prefer3 != null || prefer4 != null || location != null || child != null
            || marriage != null || gender !=null) {

         if (prefer1 != null) {
            prefer1 = stf.benefit(prefer1);

            res.put("PREFER1", prefer1);
         }
         if (prefer2 != null) {
            prefer2 = stf.benefit(prefer2);
            res.put("PREFER2", prefer2);
         }
         if (prefer3 != null) {
            prefer3 = stf.benefit(prefer3);
            res.put("PREFER3", prefer3);
         }
         if (prefer4 != null) {
            prefer4 = stf.benefit(prefer4);
            res.put("PREFER4", prefer4);
         }
         if (location != null) {
            location = stf.location(location);
            res.put("LOCATION", location);
         }
         if (child != null) {
            child = stf.child(child);
            res.put("CHILD", child);
         }
         if (marriage != null) {
            marriage = stf.child(marriage);
             res.put("MARRIGAE", marriage);
         }
         if(gender !=null){
            if(gender.equals("1")){
               gender ="Male";
               res.put("GENDER", gender);
            }else if(gender.equals("2")){
               gender = "Female";
               res.put("GENDER", gender);
            }
         }
      } else {
         String hash_key1 = null;
         String hash_value1 = null;
         Iterator entrys1 = hm.entrySet().iterator();
         while (entrys1.hasNext()) {
            Map.Entry mEntry = (Map.Entry) entrys1.next();
            hash_key1 = (String) mEntry.getKey();
            hash_value1 = (String) mEntry.getValue();
            res.put(hash_key1, hash_value1);
         }
      }

      return res;
   }
}