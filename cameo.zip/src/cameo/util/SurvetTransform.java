package cameo.util;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

public class SurvetTransform {
	public String location(String location) {
		if (location.equals("1")) {
			location = "Seoul";
		} else if (location.equals("2")) {
			location = "Gyeonggi";
		} else if (location.equals("3")) {
			location = "Incheon";
		} else if (location.equals("4")) {
			location = "Chung Nam";
		} else if (location.equals("5")) {
			location = "Chung Buk";
		} else if (location.equals("6")) {
			location = "Jeon Nam";
		} else if (location.equals("7")) {
			location = "Jeon Buk";
		} else if (location.equals("8")) {
			location = "Gyeong Nam";
		} else if (location.equals("9")) {
			location = "Gyeong Buk";
		} else if (location.equals("10")) {
			location = "Gangwon";
		} else if (location.equals("11")) {
			location = "Jeju";
		} else if (location.equals("12")) {
			location = "Ulleung/Dok do";
		}
		return location;
	}

	public String benefit(String prefer) {
		if (prefer.equals("ben1")) {
			prefer = "Gas";
		} else if (prefer.equals("ben2")) {
			prefer = "Dine out";
		} else if (prefer.equals("ben3")) {
			prefer = "Mart";
		} else if (prefer.equals("ben4")) {
			prefer = "Shopping";
		} else if (prefer.equals("ben5")) {
			prefer = "Beauty";
		} else if (prefer.equals("ben6")) {
			prefer = "Cafe";
		} else if (prefer.equals("ben7")) {
			prefer = "Bakery";
		} else if (prefer.equals("ben8")) {
			prefer = "Movie";
		} else if (prefer.equals("ben9")) {
			prefer = "Traffic";
		} else if (prefer.equals("ben10")) {
			prefer = "Telecom";
		} else if (prefer.equals("ben11")) {
			prefer = "Leisure";
		} else if (prefer.equals("ben12")) {
			prefer = "Convenience Store";
		} else if (prefer.equals("ben13")) {
			prefer = "Education";
		} else if (prefer.equals("ben14")) {
			prefer = "Cultural Life";
		} else if (prefer.equals("ben15")) {
			prefer = "Book";
		} else if (prefer.equals("ben16")) {
			prefer = "Game";
		} else if (prefer.equals("ben17")) {
			prefer = "Music";
		} else if (prefer.equals("ben18")) {
			prefer = "Travel";
		} else if (prefer.equals("ben19")) {
			prefer = "Medical";
		} else if (prefer.equals("ben20")) {
			prefer = "Overseas";
		}
		return prefer;
	}

	public HashMap Transform_Text(HashMap hm) {

		int child = 0;
		int marriage = 0;
		String t_child = null;
		String t_marriage = null;
		String prefer1 = null;
		String prefer2 = null;
		String prefer3 = null;
		String prefer4 = null;
		String location = null;
		String gender = null;

		HashMap res = new HashMap();
		SurvetTransform stf = new SurvetTransform();

		String hash_key = null;
		String hash_value = null;
		Iterator entrys = hm.entrySet().iterator();
		while (entrys.hasNext()) {
			Map.Entry mEntry = (Map.Entry) entrys.next();
			hash_key = (String) mEntry.getKey();
		}

		if (hash_key.equals("child")) {
			child = Integer.parseInt((String) hm.get("child"));
		} else if (hash_key.equals("marriage")) {
			marriage = Integer.parseInt((String) hm.get("marriage"));

		} else {
			prefer1 = (String) hm.get("prefer1");
			prefer2 = (String) hm.get("prefer2");
			prefer3 = (String) hm.get("prefer3");
			prefer4 = (String) hm.get("prefer4");
			location = (String) hm.get("location");
			gender = (String)hm.get("gender");
		}

		if (prefer1 != null || prefer2 != null || prefer3 != null || prefer4 != null || location != null || child != 0
				|| marriage != 0 || gender !=null) {

			if (prefer1 != null) {
				prefer1 = stf.benefit(prefer1);

				res.put("prefer1", prefer1);
			}
			if (prefer2 != null) {
				prefer2 = stf.benefit(prefer2);
				res.put("prefer2", prefer2);
			}
			if (prefer3 != null) {
				prefer3 = stf.benefit(prefer3);
				res.put("prefer3", prefer3);
			}
			if (prefer4 != null) {
				prefer4 = stf.benefit(prefer4);
				res.put("prefer4", prefer4);
			}
			if (location != null) {
				location = stf.location(location);
				res.put("location", location);
			}
			if (child != 0) {
				if (child == 1) {
					t_child = "Have";
					res.put("child", t_child);
				} else if (child == 2) {
					t_child = "Not";
					res.put("child", t_child);
				}
			}
			if (marriage != 0) {
				if (marriage == 1) {
					t_marriage = "Done";
					res.put("marriage", t_marriage);
				} else if (marriage == 2) {
					t_marriage = "Not";
					res.put("marriage", t_marriage);
				}
			}
			if(gender !=null){
				if(gender.equals("1")){
					gender ="Male";
					res.put("gender", gender);
				}else if(gender.equals("2")){
					gender = "Female";
					res.put("gender", gender);
				}
			}
		} else {
			String hash_key1 = null;
			String hash_value1 = null;
			Iterator entrys1 = hm.entrySet().iterator();
			while (entrys1.hasNext()) {
				Map.Entry mEntry = (Map.Entry) entrys1.next();
				hash_key1 = (String) mEntry.getKey();
				hash_value1 = (String) mEntry.getValue();
				res.put(hash_key1, hash_value1);
			}
		}

		return res;
	}
}
