package cameo.util;

public class PageNavi {
	private boolean nowFirst = false;
	private boolean nowEnd = false;
	private int totalArticle;
	private int totalPage;
	private int pageNo;
	private int newArticleCount;

	public int getNewArticleCount() {
		return newArticleCount;
	}

	public void setNewArticleCount(int newArticleCount) {
		this.newArticleCount = newArticleCount;
	}

	public int getPageNo() {
		return pageNo;
	}

	public void setPageNo(int pageNo) {
		this.pageNo = pageNo;
	}

	public int getTotalArticle() {
		return totalArticle;
	}

	public void setTotalArticle(int totalArticle) {
		this.totalArticle = totalArticle;
	}

	public int getTotalPage() {
		return totalPage;
	}

	public void setTotalPage(int totalPage) {
		this.totalPage = totalPage;
	}

	public boolean isNowEnd() {
		return nowEnd;
	}

	public void setNowEnd(boolean nowEnd) {
		this.nowEnd = nowEnd;
	}

	public boolean isNowFirst() {
		return nowFirst;
	}

	public void setNowFirst(boolean nowFirst) {
		this.nowFirst = nowFirst;
	}

	public StringBuffer pageNavi() {
		int iStartPage = ((pageNo - 1) / PageSize.PAGE_SIZE) * PageSize.PAGE_SIZE + 1;
		int iEndPage = iStartPage + PageSize.PAGE_SIZE - 1;

		if (iEndPage > this.totalPage)
			iEndPage = this.totalPage;
		
		if(pageNo > iEndPage)
			pageNo = iEndPage;

		StringBuffer sbHtml = new StringBuffer();

		sbHtml.append("<table cellpadding='0' cellspacing='0' border='0'>\n");
		sbHtml.append(" <tr>\n");
		if (this.isNowFirst()) {
			sbHtml.append("  <td><font color='#999999'>\n");
			sbHtml
					.append("   <img src='img/board/icon_prev02.gif' width='7' height='11' border='0' align='absmiddle' hspace='3'>�ֽŸ��\n");
			sbHtml
					.append("   <img src='img/board/icon_prev01_dim.gif' width='3' height='11' border='0' align='absmiddle' hspace='3'>\n");
			sbHtml.append("   ����</font>\n");
		} else {
			sbHtml.append("  <td>\n<a href='javascript:goList(1)'>");
			sbHtml
					.append("   <img src='img/board/icon_prev02.gif' width='7' height='11' border='0' align='absmiddle' hspace='3'>�ֽŸ�� </a>\n");
			sbHtml.append("   <a href='javascript:goList("
					+ ((pageNo -1) / PageSize.PAGE_SIZE * PageSize.PAGE_SIZE) + ")'>");
			sbHtml
					.append("   <img src='img/board/icon_prev01_dim.gif' width='3' height='11' border='0' align='absmiddle' hspace='3'>\n");
			sbHtml.append("   ����</a>");
		}
		sbHtml.append("  \n</td>\n");
		sbHtml.append("  <td style='padding: 0 5 0 5'>\n");
		sbHtml
				.append("   <table cellpadding='0' cellspacing='0' border='0'>\n");
		sbHtml.append("    <tr>\n");
		sbHtml
				.append("     <td width='1' nowrap><img src='img/board/n_tab.gif' width='1'");
		sbHtml.append(" height='11' border='0' align='absmiddle'><br>");
		sbHtml.append("     </td>\n");
		for (int i = iStartPage; i <= iEndPage; i++) {
			if (pageNo == i) {
				sbHtml
						.append("     <td style='padding:0 7 0 7;' nowrap><font class='text_acc_02'><b>"
								+ i + "</b></font></td>\n");
				sbHtml
						.append("     <td width='1' nowrap><img src='img/board/board_line.gif' width='1'");
				sbHtml
						.append(" height='11' border='0' align='absmiddle'><br>\n");
			} else {
				sbHtml
						.append("     <td style='padding:10 7 10 7;' nowrap><a href='javascript:goList("
								+ i + ")'>" + i + "</td>\n");
				sbHtml
						.append("     <td width='5' nowrap><img src='img/board/b_wirtecf.gif' width='5'");
				sbHtml
						.append(" height='11' border='0' align='absmiddle'><br>\n");
			}
		}
		sbHtml.append("     </td>\n");
		sbHtml.append("    </tr>\n");
		sbHtml.append("   </table>\n");
		sbHtml.append("  </td>\n");
		sbHtml.append("  <td>\n");
		if (this.isNowEnd()) {
			sbHtml.append("   <font color='#999999'>����<img");
			sbHtml
					.append("   src='img/board/icon_next01_dim.gif' width='3' height='11'");
			sbHtml.append(" border='0' align='absmiddle' hspace='3'> \n");
			sbHtml
					.append("   �����<img src='img/board/icon_next02_dim.gif' width='7' height='11'");
			sbHtml.append(" border='0' align='absmiddle' hspace='3'></font>\n");
		} else {
			sbHtml.append("   <a href='javascript:goList("
					+ ((pageNo + (PageSize.PAGE_SIZE - 1)) / PageSize.PAGE_SIZE * PageSize.PAGE_SIZE + 1) + ")'>����<img");
			sbHtml
					.append(" src='img/board/icon_next01_dim.gif' width='3' height='11'");
			sbHtml.append(" border='0' align='absmiddle' hspace='3'></a>\n");
			sbHtml
					.append("   <a href='javascript:goList("
							+ this.totalPage
							+ ")'>�����<img src='img/board/icon_next02_dim.gif' width='7' height='11'");
			sbHtml.append(" border='0' align='absmiddle' hspace='3'>\n");
		}

		sbHtml.append("  </td>\n");
		sbHtml.append(" </tr>\n");
		sbHtml.append("</table>\n");

		return sbHtml;

	}

}
