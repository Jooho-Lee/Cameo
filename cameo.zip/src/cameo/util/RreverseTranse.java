package cameo.util;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

public class RreverseTranse {
   public String location(String location) {
      if (location.equals("Seoul")) {
         location = "1";
      } else if (location.equals("Gyeonggi")) {
         location = "2";
      } else if (location.equals("Incheon")) {
         location = "3";
      } else if (location.equals("Chung Nam")) {
         location = "4";
      } else if (location.equals("Chung Buk")) {
         location = "5";
      } else if (location.equals("Jeon Nam")) {
         location = "6";
      } else if (location.equals("Jeon Buk")) {
         location = "7";
      } else if (location.equals("Gyeong Nam")) {
         location = "8";
      } else if (location.equals("Gyeong Buk")) {
         location = "9";
      } else if (location.equals("Gangwon")) {
         location = "10";
      } else if (location.equals("Jeju")) {
         location = "11";
      } else if (location.equals("Ulleung/Dok do")) {
         location = "12";
      }
      return location;
   }

   public String benefit(String prefer) {
      if (prefer.equals("Gas")) {
         prefer = "ben1";
      } else if (prefer.equals("Dine out")) {
         prefer = "ben2";
      } else if (prefer.equals("Mart")) {
         prefer = "ben3";
      } else if (prefer.equals("Shopping")) {
         prefer = "ben4";
      } else if (prefer.equals("Beauty")) {
         prefer = "ben5";
      } else if (prefer.equals("Cafe")) {
         prefer = "ben6";
      } else if (prefer.equals("Bakery")) {
         prefer = "ben7";
      } else if (prefer.equals("Movie")) {
         prefer = "ben8";
      } else if (prefer.equals("Traffic")) {
         prefer = "ben9";
      } else if (prefer.equals("Telecom")) {
         prefer = "ben10";
      } else if (prefer.equals("Leisure")) {
         prefer = "ben11";
      } else if (prefer.equals("Convenience Store")) {
         prefer = "ben12";
      } else if (prefer.equals("Education")) {
         prefer = "ben13";
      } else if (prefer.equals("Cultural Life")) {
         prefer = "ben14";
      } else if (prefer.equals("Book")) {
         prefer = "ben15";
      } else if (prefer.equals("Game")) {
         prefer = "ben16";
      } else if (prefer.equals("Music")) {
         prefer = "ben17";
      } else if (prefer.equals("Travel")) {
         prefer = "ben18";
      } else if (prefer.equals("Medical")) {
         prefer = "ben19";
      } else if (prefer.equals("Overseas")) {
         prefer = "ben20";
      }
      return prefer;
   }

   public HashMap Transform_Text(HashMap hm) {

      String child = null;
      String marriage = null;
      String t_child = null;
      String t_marriage = null;
      String prefer1 = null;
      String prefer2 = null;
      String prefer3 = null;
      String prefer4 = null;
      String location = null;
      String gender = null;

      HashMap res = new HashMap();
      RreverseTranse stf = new RreverseTranse();

      String hash_key = null;
      Iterator entrys = hm.entrySet().iterator();
      while (entrys.hasNext()) {
         Map.Entry mEntry = (Map.Entry) entrys.next();
         hash_key = (String)mEntry.getKey();
         System.out.println("entry : " + hash_key);
      }

      if (hash_key.equals("child")) {
         child = (String) hm.get("child");
      } else if (hash_key.equals("marriage")) {
         marriage = (String) hm.get("marriage");

      } else {
         prefer1 = (String) hm.get("prefer1");
         prefer2 = (String) hm.get("prefer2");
         prefer3 = (String) hm.get("prefer3");
         prefer4 = (String) hm.get("prefer4");
         location = (String) hm.get("location");
         gender = (String)hm.get("gender");
      }

      if (prefer1 != null || prefer2 != null || prefer3 != null || prefer4 != null || location != null || child != null
            || marriage != null || gender !=null) {

         if (prefer1 != null) {
            prefer1 = stf.benefit(prefer1);

            res.put("prefer1", prefer1);
         }
         if (prefer2 != null) {
            prefer2 = stf.benefit(prefer2);
            res.put("prefer2", prefer2);
         }
         if (prefer3 != null) {
            prefer3 = stf.benefit(prefer3);
            res.put("prefer3", prefer3);
         }
         if (prefer4 != null) {
            prefer4 = stf.benefit(prefer4);
            res.put("prefer4", prefer4);
         }
         if (location != null) {
            location = stf.location(location);
            res.put("location", location);
         }
         if (child != null) {
            if (child == "Have") {
               t_child = "1";
               res.put("child", t_child);
            } else if (child == "Not") {
               t_child = "2";
               res.put("child", t_child);
            }
         }
         if (marriage != null) {
            if (marriage == "Done") {
               t_marriage = "1";
               res.put("marriage", t_marriage);
            } else if (marriage == "Not") {
               t_marriage = "2";
               res.put("marriage", t_marriage);
            }
         }
         if(gender !=null){
            if(gender.equals("Male")){
               gender ="1";
               res.put("gender", gender);
            }else if(gender.equals("Female")){
               gender = "2";
               res.put("gender", gender);
            }
         }
      } else {
         String hash_key1 = null;
         String hash_value1 = null;
         Iterator entrys1 = hm.entrySet().iterator();
         while (entrys1.hasNext()) {
            Map.Entry mEntry = (Map.Entry) entrys1.next();
            hash_key1 = (String) mEntry.getKey();
            hash_value1 = (String) mEntry.getValue();
            res.put(hash_key1, hash_value1);
         }
      }

      return res;
   }
}