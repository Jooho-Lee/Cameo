package cameo.dao;

import java.util.ArrayList;
import java.util.HashMap;

import org.apache.ibatis.session.SqlSessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import cameo.entity.Card_Benefit;

@Repository("cardDao")
public class CardDao {

	@Autowired
	private SqlSessionFactory factory;

	public ArrayList<String[]> getSuggestSaving(ArrayList card) {

		HashMap<String, String> suggest = new HashMap<>();

		suggest.put("cardType", (String) card.get(0));
		suggest.put("benType", (String) card.get(1));
		suggest.put("prefer1", (String) card.get(2));
		suggest.put("prefer2", (String) card.get(3));
		suggest.put("seq", String.valueOf(card.get(4)));
		
		ArrayList bensugg = (ArrayList)factory.openSession().selectList("suggestCard.suggestSaving", suggest);
		factory.openSession().close();
				
		return bensugg;
	}

	public ArrayList getSortBen1(ArrayList toSavingSort) {
		
		ArrayList resultBen = new ArrayList();
		for (int i = 0; i < toSavingSort.size(); i++) {
			int seq = (int) toSavingSort.get(i);
			HashMap<String, String> card = factory.openSession().selectOne("suggestCard.getSortBen", seq);
			resultBen.add(card);
			factory.openSession().close();
		}
		return resultBen;
	}

	public ArrayList SuggestPattern(HashMap survey) {
		ArrayList surveyRes = new ArrayList();
		if (survey.get("cnt").equals("1")) {
			surveyRes = (ArrayList) factory.openSession().selectList("suggestCard.suggestPattern1", survey);
			factory.openSession().close();
		} else if (survey.get("cnt").equals("2")) {
			surveyRes = (ArrayList) factory.openSession().selectList("suggestCard.suggestPattern2", survey);
			factory.openSession().close();
		} else if (survey.get("cnt").equals("3")) {
			surveyRes = (ArrayList) factory.openSession().selectList("suggestCard.suggestPattern3", survey);
			factory.openSession().close();
		} else if (survey.get("cnt").equals("4")) {
			surveyRes = (ArrayList) factory.openSession().selectList("suggestCard.suggestPattern4", survey);
			factory.openSession().close();
		}
		return surveyRes;
	}

}
