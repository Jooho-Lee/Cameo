package cameo.dao;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.apache.ibatis.session.SqlSessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import cameo.entity.*;

@Repository("boardDao")
public class BoardDAO {

	@Autowired
	private SqlSessionFactory factory;

	public int writeArticle(BoardDTO boardDTO) {
		int seq = this.getNextSeq();
		boardDTO.setQ_seq(seq);
		factory.openSession().insert("board.writeArticle", boardDTO);
		factory.openSession().close();
		return seq;
	}

	private int getNextSeq() {
		int seq = factory.openSession().selectOne("board.nextSeq");
		factory.openSession().close();
		return seq;
	}

	public BoardDTO getArticle(int seq) {
		BoardDTO article = factory.openSession().selectOne("board.getArticle", seq);
		factory.openSession().close();
		return article;
	}

	public List<BoardDTO> getList(HashMap<String, Object> map) {
		List<BoardDTO> boardList = new ArrayList<BoardDTO>();
		int idx = 0;
		int end = (int) map.get("end");
		int start = (int) map.get("start");
		String key = (String) map.get("key");
		String word = (String) map.get("word");

		if (key != null && key.length() != 0) {
			if (key.equals("subject")) {// ����˻�
				boardList = factory.openSession().selectList("board.subjectBoard", map);
			} else if (key.equals("q_seq") || key.equals("user_id")) // �۹�ȣ,�ۼ���
																		// �˻�
				boardList = factory.openSession().selectList("board.userBoard", map);
		} else {
			boardList = factory.openSession().selectList("board.listBoard", map);
		}
		factory.openSession().close();
		return boardList;
	}

	public int getTotalArticleCount(HashMap<String, Object> map) {
		int totalAticleCount = 0;

		String key = (String) map.get("key");
		String word = (String) map.get("word");
		if (key != null && key.length() != 0) {
			if (key.equals("subject")) {
				totalAticleCount = factory.openSession().selectOne("board.subCount", map);
			} else if (key.equals("q_seq") || key.equals("user_id")) {
				totalAticleCount = factory.openSession().selectOne("board.userCount", map);
			}
		} else {
			totalAticleCount = factory.openSession().selectOne("board.listCount", map);
		}
		factory.openSession().close();
		return totalAticleCount;
	}

	public int getNewArticleCount(int btype) {
		int cnt = factory.openSession().selectOne("board.newCount");
		factory.openSession().close();
		return cnt;
	}

	public void updatHit(int seq) {
		factory.openSession().update("board.updateHit", seq);
		factory.openSession().close();
	}

	public int replyArticle(BoardDTO boardDTO) {
		int seq = this.getNextSeq();
		System.out.println(seq);
		factory.openSession().update("board.updateParent", boardDTO);
		factory.openSession().close();
		//////////////////////////////// reply insert
		boardDTO.setQ_seq(seq);
		factory.openSession().insert("board.writeReply", boardDTO);
		factory.openSession().close();

		////////////////////////////////// reply update
		factory.openSession().update("board.updateReply", boardDTO);
		factory.openSession().close();
		return seq;
	}

	public int modifyArticle(BoardDTO boardDTO) {
		int res = factory.openSession().update("board.modifyArticle", boardDTO);
		factory.openSession().close();
		if(res>0){
			System.out.println("update����");
		}else{
			System.out.println("update ����");
		}
		
		return boardDTO.getQ_seq();
	}

	public int deleteArticle(int seq) {
		int res = factory.openSession().update("board.deleteArticle", seq);
		factory.openSession().close();
		if(res>0){
			System.out.println("update����");
		}else{
			System.out.println("update ����");
		}
		return seq;
	}
}
