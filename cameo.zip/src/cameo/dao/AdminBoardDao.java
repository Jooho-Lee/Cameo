package cameo.dao;


import java.util.List;

import org.apache.ibatis.session.SqlSessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import cameo.entity.*;

@Repository("AdminBoardDao")
public class AdminBoardDao {
	
	@Autowired
	private SqlSessionFactory factory;
	
	public boolean NoticeInsert(Notice ntc){
		int n = 0;
		n = factory.openSession().insert("noticenamespace.insertBoard", ntc);
		
		return (n>0)? true : false;
	}
	
	public List<Notice> NoticeAll() {
		return factory.openSession().selectList("noticenamespace.listBoard");
	}
	
	public Notice NoticeFind(int notice_Seq){
		Notice notice = new Notice();		
		notice = factory.openSession().selectOne("noticenamespace.findBoard", notice_Seq);
		
		return notice;
	}
	
	public boolean NoticeUpdate(Notice ntc) {
		int n = 0;
		n = factory.openSession().update("noticenamespace.updateBoard", ntc);
		
		return (n>0)? true : false;
	}
	
	public boolean NoticeDelete(int Notice_Seq){
		int n = 0;
		n = factory.openSession().delete("noticenamespace.deleteBoard", Notice_Seq);		
		
		return (n>0)? true : false;
	}
}
