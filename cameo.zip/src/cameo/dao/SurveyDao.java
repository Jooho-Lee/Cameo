package cameo.dao;

import java.util.HashMap;
import java.util.Map;

import org.apache.ibatis.session.SqlSessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import cameo.entity.Survey;
import cameo.util.SurvetTransform;
import cameo.util.SurvetTransformVer2;

@Repository("surveyDao")
public class SurveyDao {
	
	@Autowired
	private SqlSessionFactory factory;
	
	public int SurveyInsert(Survey su) {
		int n = factory.openSession().insert("surveynamespace.insertSurvey", su);
		factory.openSession().close();
		return n;
	}

	public HashMap getSurveyAll(int su_seq) {
		HashMap<String, String> res = factory.openSession().selectOne("surveynamespace.surveyAll", su_seq);
		factory.openSession().close();
		return res;
	}
}
