package cameo.dao;

import java.util.HashMap;

import org.apache.ibatis.session.SqlSessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import cameo.entity.JMember;
import cameo.entity.Survey;

@Repository("joinDao")
public class MemberDao {

	@Autowired
	private SqlSessionFactory factory;

	public int MemberInsert(JMember jm) {
		int n = factory.openSession().insert("joinnamespace.insertMember", jm);
		
		return n;
	}

	public int LoginCheck(JMember mem) {
		int res = 0;
		JMember check = factory.openSession().selectOne("joinnamespace.LoginCheck", mem);
		if (check != null) {
			res = 1;
			
		}
		
		return res;
	}

	public HashMap LoginSubmit(String id) {
		
		HashMap su_check = new HashMap();
		factory.openSession().update("joinnamespace.LoginSubmit", id);
		Survey rs = factory.openSession().selectOne("joinnamespace.getLoginSubmit", id);
		if (rs != null) {
			su_check.put("seq", rs.getCol());
			su_check.put("su_date", rs.getSurveyDate());
		} else {
			su_check.put("seq", 0);
		}
		
		return su_check;
	}
}
