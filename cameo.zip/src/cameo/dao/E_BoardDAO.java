package cameo.dao;

import java.sql.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.apache.ibatis.session.SqlSessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import cameo.entity.*;

@Repository("e_boardDao")
public class E_BoardDAO {
	
	@Autowired
	private SqlSessionFactory factory;

	
	public List<Card_Benefit> getBoardType() {//E_BoardTypeDTO->Card_Benefit
		List<Card_Benefit> listBtype = factory.openSession().selectList("e_boardtype.listBType");
		factory.openSession().close();
		return listBtype;
	}

	public List<Card_Benefit> getCardList(int btype){//E_BoardTypeDTO->Card_Benefit
		List<Card_Benefit> listCard = factory.openSession().selectList("e_boardtype.listCard", btype);
		factory.openSession().close();
		return listCard;	
	}

	public int writeArticle(E_BoardDTO e_boardDTO) {
		int seq = this.getNextSeq();
		e_boardDTO.setBoard_Seq(seq);
		factory.openSession().insert("e_board.writeArticle", e_boardDTO);
		factory.openSession().close();
		return seq;
	}

	private int getNextSeq() {
		int seq = factory.openSession().selectOne("e_board.nextSeq");
		factory.openSession().close();
		return seq;
	}

	public E_BoardDTO getArticle(int seq) {
		E_BoardDTO article = factory.openSession().selectOne("e_board.getArticle", seq);
		factory.openSession().close();
		return article;
	}

	public List<E_BoardDTO> getList(HashMap<String, Object> map) {
		List<E_BoardDTO> e_boardList = new ArrayList<E_BoardDTO>();
		int idx = 0;
		int btype = (int) map.get("btype");
		int end = (int) map.get("end");
		int start = (int) map.get("start");
		String key = (String) map.get("key");
		String word = (String) map.get("word");
		
		if (key != null && key.length() != 0) {
			if (key.equals("board_text")) {// ����˻�
				e_boardList = factory.openSession().selectList("e_board.textBoard", map);
			} else if (key.equals("board_seq") || key.equals("user_id")) // �۹�ȣ,�ۼ���
																		// �˻�
				e_boardList = factory.openSession().selectList("e_board.userBoard", map);
		} else {
			e_boardList = factory.openSession().selectList("e_board.listBoard", map);
		}
		factory.openSession().close();
		return e_boardList;
		
		
	}

	public int getTotalArticleCount(HashMap<String, Object> map) {
		int totalAticleCount = 0;

		int btype = (int) map.get("btype");
		String key = (String) map.get("key");
		String word = (String) map.get("word");
		if (key != null && key.length() != 0) {
			if (key.equals("board_Text")) {
				totalAticleCount = factory.openSession().selectOne("e_board.textCount", map);
			} else if (key.equals("board_Seq") || key.equals("user_id")) {
				totalAticleCount = factory.openSession().selectOne("e_board.userCount", map);
			}
		} else {
			totalAticleCount = factory.openSession().selectOne("e_board.listCount", map);
		}
		factory.openSession().close();
		return totalAticleCount;
	}

	public int getNewArticleCount(int btype) {
		int cnt = factory.openSession().selectOne("e_board.newCount",btype);
		factory.openSession().close();
		return cnt;
		
	}

	public void updatHit(int seq) {
		factory.openSession().update("e_board.updateHit", seq);
		factory.openSession().close();
	}

	public int replyArticle(E_BoardDTO e_boardDTO) {
		int seq = this.getNextSeq();
		factory.openSession().update("e_board.updateParent", e_boardDTO);
		factory.openSession().close();
		//////////////////////////////// reply insert
		e_boardDTO.setBoard_Seq(seq);
		factory.openSession().insert("e_board.writeReply", e_boardDTO);
		factory.openSession().close();
		////////////////////////////////// reply update
		factory.openSession().update("e_board.updateReply", e_boardDTO);
		factory.openSession().close();
		return seq;
	}

	public int modifyArticle(E_BoardDTO e_boardDTO) {
		int res = factory.openSession().update("e_board.modifyArticle", e_boardDTO);
		factory.openSession().close();
		if(res>0){
			System.out.println("update����");
		}else{
			System.out.println("update ����");
		}
		
		return e_boardDTO.getBoard_Seq();
	}

	public int deleteArticle(int seq) {
		int res = factory.openSession().update("e_board.deleteArticle", seq);
		factory.openSession().close();
		if(res>0){
			System.out.println("update����");
		}else{
			System.out.println("update ����");
		}
		return seq;
	}


}
