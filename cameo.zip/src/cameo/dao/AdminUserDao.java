package cameo.dao;

import java.util.List;

import org.apache.ibatis.session.SqlSessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import cameo.entity.JMember;

@Repository("adminUserDao")
public class AdminUserDao {

	@Autowired
	private SqlSessionFactory factory;
	
	public List<JMember> getUserAll(){
		
		return factory.openSession().selectList("adminusernamespace.listUser");
	}
	
	public JMember getUserFind(String User_ID){
		JMember jmember= new JMember();
		jmember = factory.openSession().selectOne("adminusernamespace.findUser", User_ID);
		
		return jmember;
	}
	
	public int getUserUpdate(JMember jm){
		
		int r= factory.openSession().update("adminusernamespace.updateUser", jm);
		
		return r;
	}
	
	public int getUserDelete(String User_ID){
		
		int r = factory.openSession().delete("adminusernamespace.deleteUser", User_ID);
		
		return r;
	}
}
