package cameo.dao;

import java.util.List;

import org.apache.ibatis.session.SqlSessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import cameo.entity.Card_Benefit;

@Repository("AdminCardBenefitDao")
public class AdminCardBenefitDao {
	
	@Autowired
	private SqlSessionFactory factory;
	
	public List<Card_Benefit> listCard() {
		List<Card_Benefit> res = factory.openSession().selectList("card_benefit.listCard");
		
		return res;
	}
	
	public Card_Benefit findCard(int Card_Seq) {
		Card_Benefit card = factory.openSession().selectOne("card_benefit.findCard", Card_Seq);		
		
		return card;
	}

	
	public boolean insertCard(Card_Benefit c_entity) {
		String seq = factory.openSession().selectOne("card_benefit.cardSeqForBenefit");
		c_entity.setCard_Seq(Integer.parseInt(seq)-1);
		int n = factory.openSession().insert("card_benefit.insertCard", c_entity);
		
		return (n>0)? true : false;
	}

	
	public boolean insertBenefit(Card_Benefit benefit) {
		String seq = factory.openSession().selectOne("card_benefit.cardSeqForBenefit");
		benefit.setCard_Seq(Integer.parseInt(seq)-1);
		int res = factory.openSession().insert("card_benefit.insertBenefit", benefit);
		
		return (res>0)? true : false;
	}
	
	public boolean updateCard(Card_Benefit c_entity) {
		int n = factory.openSession().update("card_benefit.updateCard", c_entity);
		
		return (n>0)? true : false;
	}

	
	public boolean deleteCard(int card_seq) {
		
		int check = factory.openSession().selectOne("card_benefit.Check", card_seq);
		int res = 0;
		int benefit_delete = 0;
		
		if(check > 0){
			benefit_delete = factory.openSession().delete("card_benefit.deleteBenefitAll", card_seq);
			if(benefit_delete > 0){
				res = factory.openSession().delete("card_benefit.deleteCard", card_seq);
			}
		}else{
			res = factory.openSession().delete("card_benefit.deleteCard", card_seq);
		}
		
		return (res>0)? true : false;
	}
	
	public List<Card_Benefit> BenefitAll() {
		
		return factory.openSession().selectList("card_benefit.listBenefit");
	}
	
	public Card_Benefit BenefitFind(int Ben_Seq) {
		Card_Benefit card_benefit = new Card_Benefit();
		card_benefit = factory.openSession().selectOne("card_benefit.findBenefit", Ben_Seq);
		
		return card_benefit;
	}
	
	public boolean BenefitUpdate(Card_Benefit b_entity) {
		
		int n = 0;
		n = factory.openSession().update("card_benefit.updateBenefit", b_entity);
		
		return (n>0)? true : false;
	}
	
	public boolean BenefitDelete(int ben_Seq) {
		
		int n = 0;
		n = factory.openSession().delete("card_benefit.deleteBenefit", ben_Seq);		
		
		return (n>0)? true : false;
	}
}
