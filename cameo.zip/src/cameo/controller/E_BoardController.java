package cameo.controller;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import cameo.entity.*;
import cameo.biz.*;
import cameo.util.*;


@Controller
public class E_BoardController extends HttpServlet {
	
	E_BoardManager e_boardManager;

	@Autowired
	public E_BoardController(E_BoardManager e_boardManager){
		
		super();
		this.e_boardManager = e_boardManager;
	}
	
	@RequestMapping("/e_board.sp")
	private ModelAndView execute(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		ModelAndView mav = null;
		
		String root = request.getContextPath();
		String act = request.getParameter("act");
		int btype = NumberCheck.nullToZero(request.getParameter("btype"));		
		int pg = NumberCheck.nullToOne(request.getParameter("pg"));
		String key = StringCheck.nullToBlank(request.getParameter("key"));
		String word = Encoder.isoToEuc(StringCheck.nullToBlank(request.getParameter("word")));
		
		ArrayList<Object> qs = new ArrayList<Object>();
		qs.add(pg);
		qs.add(btype);
		qs.add(key);
		qs.add(Encoder.urlEncode(word));
		
		boolean flag = true;

		if("btype".equals(act)) {//E_BoardTypeDTO->Card_Benefit
			List<Card_Benefit> list = e_boardManager.getBoardType();
			request.setAttribute("btype", list);
			mav = new ModelAndView("/board/e_board", "qs", qs);
			flag = false;
		}
			else if ("mvnew".equals(act)) {
			mav = new ModelAndView("/board/e_write","qs", qs);
			flag=false;
			//�۵��
		} 
		else if ("newwrite".equals(act)) {

			//////////////// session���� �ۼ��� ���� ��� //////////////
			HttpSession session = request.getSession();
			String id = (String)session.getAttribute("user_id");
		
			E_BoardDTO e_boardDTO = new E_BoardDTO();
			e_boardDTO.setUser_ID(id);
			e_boardDTO.setBoard_Text(request.getParameter("board_Text"));
			e_boardDTO.setBtype(Integer.parseInt(request.getParameter("btype")));
			int seq = e_boardManager.writeArticle(e_boardDTO);
			if (seq != 0){
				qs.add(seq);
				mav = new ModelAndView("/board/e_writeOk","qs",qs);
			}
			else{
				mav = new ModelAndView("/board/e_writeFail","qs",qs);
			}

			flag=false;
		} else if ("mvreply".equals(act)) {
			int seq = NumberCheck.nullToZero(request.getParameter("board_Seq"));
			E_BoardDTO e_boardDTO = e_boardManager.getArticle(seq, 1);// ��ۿ� ����
																	// ��������.			
			request.setAttribute("replyArticle", e_boardDTO);
			flag = false;
			mav= new ModelAndView("board/e_reply","qs",qs);
		} else if ("replywrite".equals(act)) {
			//////////////// session���� �ۼ��� ���� ��� //////////////
			HttpSession session = request.getSession();
			String user_id = (String) session.getAttribute("user_id");

			E_BoardDTO e_boardDTO = new E_BoardDTO();
			e_boardDTO.setUser_ID(user_id);
			e_boardDTO.setBoard_Text(request.getParameter("board_Text"));
			e_boardDTO.setBtype(Integer.parseInt(request.getParameter("btype")));
			e_boardDTO.setBoard_Ref(NumberCheck.nullToZero(request.getParameter("board_Ref")));
			e_boardDTO.setBoard_Step(NumberCheck.nullToZero(request.getParameter("board_Step"))+1);
			e_boardDTO.setBoard_Lev(NumberCheck.nullToZero(request.getParameter("board_Lev"))+1);
			e_boardDTO.setBoard_Pseq(NumberCheck.nullToZero(request.getParameter("board_Pseq")));

			int seq = e_boardManager.replyArticle(e_boardDTO);

			if (seq != 0){
				qs.add(seq);
				flag=false;
				mav = new ModelAndView("board/e_writeOk","qs",qs);
			}
				
			else{
				flag=false;
				mav = new ModelAndView("board/e_writeFail","qs",qs);
			}
		} else if ("list".equals(act)) {
			//�Խ��� ���� ��´�.
			List<E_BoardDTO> e_boardlist = e_boardManager.getList(btype, pg, key, word);
			request.setAttribute("boardList", e_boardlist);
			//�� ���� �������°�
			PageNavi pageNavi = e_boardManager.getPageNavi(btype, pg, key, word);
			request.setAttribute("pageNavi", pageNavi);
			List<Card_Benefit> cardlist = e_boardManager.getCardList(btype);
//E_BoardTypeDTO->Card_Benefit
			request.setAttribute("cardList", cardlist);
			flag = false;
			mav = new ModelAndView("board/e_list","qs", qs);
		}
		else if ("modify".equals(act)) {
			int seq = NumberCheck.nullToZero(request.getParameter("board_Seq"));
			E_BoardDTO e_boardDTO = e_boardManager.getArticle(seq, 1);// ������ ����
																	// ��������.
			
			request.setAttribute("modify", e_boardDTO);
			flag = false;
			mav= new ModelAndView("board/e_modify","qs",qs);
		} else if ("modifyarticle".equals(act)) {
			int seq = NumberCheck.nullToZero(request.getParameter("board_Seq"));
			E_BoardDTO e_boardDTO = new E_BoardDTO();
			e_boardDTO.setBoard_Text(request.getParameter("board_Text"));
			e_boardDTO.setBoard_Seq(seq);
			e_boardManager.modifyArticle(e_boardDTO);
			flag = false;
			mav= new ModelAndView("board/e_modifyOk","qs",qs);
		} else if ("delete".equals(act)) {
			int seq = NumberCheck.nullToZero(request.getParameter("board_Seq"));
			int a = e_boardManager.deleteArticle(seq);
			if (a > 0) {
				flag=false;
				mav=new ModelAndView("board/e_deleteOk","qs",qs);
			}
		}
		if (flag){
			mav = new ModelAndView("../../index");
		}
		return mav;
	}
}