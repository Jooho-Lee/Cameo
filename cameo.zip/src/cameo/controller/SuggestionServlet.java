package cameo.controller;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import cameo.biz.*;
import cameo.util.RreverseTranse;

@Controller
public class SuggestionServlet extends HttpServlet {

	Suggestion_DB suggestion_DB;
	Survey_DB survey_DB;

	@Autowired
	public SuggestionServlet(Suggestion_DB suggestion_DB, Survey_DB survey_DB) {
		super();
		this.suggestion_DB = suggestion_DB;
		this.survey_DB = survey_DB;
	}

	@RequestMapping(value="/SuggestPattern.sp")
   public ModelAndView SuggestPattern(@RequestParam("seq") String seq,
      @RequestParam("annualfee") String annualfee,
      @RequestParam("income") String income,
      @RequestParam("saving") String saving,
      @RequestParam("cardRate") String cardRate,
      @RequestParam("cardType") String cardType,
      @RequestParam("bentype") String bentype,
      @RequestParam("prefer1") String prefer1,
      @RequestParam("prefer2") String prefer2,
      @RequestParam("prefer3") String prefer3,
      @RequestParam("prefer4") String prefer4) {

      HashMap survey = new HashMap();
      HashMap temp = new HashMap();
      RreverseTranse rt = new RreverseTranse();

      String ben1 = null;
      String ben2 = null;
      String ben3 = null;
      String ben4 = null;
      

      survey.put("seq", seq);
      survey.put("annualfee", annualfee);
      survey.put("income", income);
      survey.put("saving", saving);
      survey.put("cardRate", cardRate);
      survey.put("cardType", cardType);
      survey.put("bentype", bentype);

      temp.put("prefer1", prefer1);
      survey.put("prefer1", rt.Transform_Text(temp).get("prefer1"));
      ben1 = (String) survey.get("prefer1");
      temp.clear();

      if (!prefer2.equals("null")) {
         temp.put("prefer2", prefer2);
         survey.put("prefer2", rt.Transform_Text(temp).get("prefer2"));
         ben2 = (String) survey.get("prefer2");
         temp.clear();
         survey.put("cnt", "2");

         if (!prefer3.equals("null")) {
            temp.put("prefer3", prefer3);
            survey.put("prefer3", rt.Transform_Text(temp).get("prefer3"));
            ben3 = (String) survey.get("prefer3");
            temp.clear();
            survey.put("cnt", "3");

            if (!prefer4.equals("null")) {
               temp.put("prefer4", prefer4);
               survey.put("prefer4", rt.Transform_Text(temp).get("prefer4"));
               ben4 = (String) survey.get("prefer4");
               temp.clear();
               survey.put("cnt", "4");
            }
         }
      } else {
         survey.put("cnt", "1");
      }

      ArrayList<String> surveyCard = (ArrayList<String>)suggestion_DB.SuggestPattern(survey);
      ArrayList surveySort = new ArrayList();
      ArrayList surveyBenSort = new ArrayList();
      ArrayList SurveysortBenall = new ArrayList();

      
      if (survey.get("cnt").equals("1")) {
         surveySort = suggestion_DB.getSavingSort(surveyCard, ben1);
         surveyBenSort = (ArrayList) suggestion_DB.getSortBen1(surveySort);
          SurveysortBenall = suggestion_DB.getBenSplit(surveyBenSort);
        
      } else if (survey.get("cnt").equals("2")) {
         surveySort = suggestion_DB.getSavingSort(surveyCard, ben1, ben2);
         surveyBenSort = (ArrayList) suggestion_DB.getSortBen1(surveySort);
         SurveysortBenall = suggestion_DB.getBenSplit(surveyBenSort);
      }else if (survey.get("cnt").equals("3")) {
         surveySort = suggestion_DB.getSavingSort(surveyCard, ben1, ben2, ben3);
         surveyBenSort = (ArrayList) suggestion_DB.getSortBen1(surveySort);
         SurveysortBenall = suggestion_DB.getBenSplit(surveyBenSort);
      }else if (survey.get("cnt").equals("4")) {
         surveySort = suggestion_DB.getSavingSort(surveyCard, ben1, ben2, ben3, ben4);
         surveyBenSort = (ArrayList) suggestion_DB.getSortBen1(surveySort);
         SurveysortBenall = suggestion_DB.getBenSplit(surveyBenSort);
      }
      
      return new ModelAndView("suggestion/surveyRes", "SurveysortBenall", SurveysortBenall);
   }

	@RequestMapping(value="/surveyFind.sp")
	private ModelAndView surveyFind(HttpServletRequest request, HttpServletResponse response) {
		
		HttpSession su = request.getSession();
		HashMap su_check = (HashMap) su.getAttribute("su_check");
		int su_seq = (int) su_check.get("seq");
		HashMap surveyAll = survey_DB.getSurveyAll(su_seq);
		request.setAttribute("surveyAll", surveyAll);

		return new ModelAndView("suggestion/suggest_by_pattern");
	}
	
	@RequestMapping(value="/toSuggestSaving.sp")
	private ModelAndView toSuggestSaving(){
		ModelAndView mav = new ModelAndView("suggestion/suggest_by_saving");
		
		return mav;
	}
	@RequestMapping(value="/SuggestSaving.sp", method=RequestMethod.POST)
	private ModelAndView SuggestSaving(HttpServletRequest request,
			@RequestParam(value = "cardtype") String cardtype, @RequestParam(value = "bentype") String bentype,
			@RequestParam(value = "benefit1") String benefit1, @RequestParam(value = "benefit2") String benefit2) {
		
		
		//���� seq���
		HttpSession su = request.getSession();
		HashMap su_check = (HashMap) su.getAttribute("su_check");
		int su_seq = (int) su_check.get("seq");

		ArrayList card = new ArrayList();
		card.add(cardtype);
		card.add(bentype);
		card.add(benefit1);
		card.add(benefit2);
		card.add((su_seq));

		// 1����
		ArrayList bensugg = suggestion_DB.getSuggestSaving(card);
		ArrayList toSavingSort = suggestion_DB.getSavingSort(bensugg, benefit1);
		ArrayList sortBen1 = suggestion_DB.getSortBen1(toSavingSort);
		ArrayList sortBenall = suggestion_DB.getBenSplit(sortBen1);
		
		
		
		// ����
		//ArrayList bensuggMix = suggestion_DB.getSuggestSavingMix(card);
		ArrayList toSavingSortMix = suggestion_DB.getSavingSortMix(bensugg, benefit1, benefit2);
		ArrayList sortBenMix = suggestion_DB.getSortBen1(toSavingSortMix);
		ArrayList sortBenMixall = suggestion_DB.getBenSplit(sortBenMix);
		
		ArrayList zip = new ArrayList();
		
		zip.add(sortBenall);
		zip.add(sortBenMixall);
				
		ModelAndView mav = new ModelAndView("suggestion/firBen", "zip", zip);
		
		return mav;
	}
}
