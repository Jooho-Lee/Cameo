package cameo.controller;

import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import cameo.biz.*;
import cameo.entity.*;


@Controller
public class Admin_Board_Servlet{
	Admin_Board_DB admin_Board_DB;       
	Logger log = Logger.getLogger(this.getClass());
    @Autowired
	public Admin_Board_Servlet(Admin_Board_DB admin_Board_DB) {
        super();
        this.admin_Board_DB = admin_Board_DB;
    }
    
    @RequestMapping(value="/NoticeInsert.sp", method=RequestMethod.POST)
	private ModelAndView NoticeInsert(@ModelAttribute Notice ntc) {
    	ModelAndView mav = null;		
			
		if(admin_Board_DB.NoticeInsert(ntc)!= true){
			mav = new ModelAndView("admin_page/BoardMain");
		}else{
			List<Notice> list = admin_Board_DB.NoticeAll();
			mav = new ModelAndView("redirect:./NoticeAll.sp","all",list);
		}
		
		return mav;
	}


	@RequestMapping("/NoticeAll.sp")
	public ModelAndView NoticeAll(){
		List<Notice> list = admin_Board_DB.NoticeAll();
		ModelAndView mav = new ModelAndView("admin_page/BoardMain","all",list);
		
		return mav;
	}
	
	@RequestMapping("/NoticeToMain.sp")
	public ModelAndView NoticeToMain() {
		List<Notice> res = admin_Board_DB.NoticeAll();
		ModelAndView mav = new ModelAndView("main","all", res);
		
		return mav;		
	}
	@RequestMapping("/adminPage.sp")
	public ModelAndView adminMain() {
		ModelAndView mav = new ModelAndView("admin_page/Admin_Main");
		
		return mav;		
	}
	
	@RequestMapping("/NoticeFind.sp")
	public ModelAndView NoticeFind(@RequestParam(value="Notice_Seq") int Notice_Seq){
		Notice nts = admin_Board_DB.NoticeFind(Notice_Seq);
		
		return new ModelAndView("admin_page/NoticeUpdate","find",nts);		
	}
	
	@RequestMapping(value="/NoticeUpdate.sp", method=RequestMethod.POST)
	public ModelAndView NoticeUpdate(@RequestParam(value="Notice_Seq") int Notice_Seq, @RequestParam(value="Notice_Text") String Notice_Text, 
			@RequestParam(value="Notice_C_Date") String Notice_C_Date,@RequestParam(value="Notice_A_Date") String Notice_A_Date){
		Notice ntc = new Notice(Notice_Seq, Notice_Text, Notice_C_Date, Notice_A_Date);
		admin_Board_DB.NoticeUpdate(ntc);
		
		return new ModelAndView("redirect:./NoticeAll.sp");		
	}
	
	@RequestMapping("/NoticeDelete.sp")
	public ModelAndView delete(@RequestParam(value="Notice_Seq") int Notice_Seq){
		admin_Board_DB.NoticeDelete(Notice_Seq);
		
		return new ModelAndView("redirect:./NoticeAll.sp");
	}	
	
}
