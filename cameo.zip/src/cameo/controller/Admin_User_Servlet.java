package cameo.controller;

import java.io.File;
import java.util.Enumeration;
import java.util.List;

import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.oreilly.servlet.MultipartRequest;
import com.oreilly.servlet.multipart.DefaultFileRenamePolicy;

import cameo.entity.JMember;
import cameo.biz.Admin_User_DB;


@Controller
public class Admin_User_Servlet extends HttpServlet {

	Admin_User_DB adminUserDB;
	Logger log = Logger.getLogger(this.getClass());
	
	@Autowired
	public Admin_User_Servlet(Admin_User_DB adminUserDB) {
		super();
		this.adminUserDB = adminUserDB;
	}

	@RequestMapping("/UserAll.sp")
	public ModelAndView UserAll() {
		List<JMember> res = adminUserDB.getUserAll();
		ModelAndView mav = new ModelAndView("/admin_page/UserInfo", "all", res);
		
		return mav;
	}

	@RequestMapping("/UserFind.sp")
	public ModelAndView UserFind(@RequestParam("User_ID") String User_ID){
		JMember res = adminUserDB.getUserFind(User_ID);
		
		return new ModelAndView("/admin_page/UserUpdate", "find", res);
	}

	@RequestMapping("/UserUpdate.sp")
	public ModelAndView UserUpdate(HttpServletRequest request) throws Exception{
		int maxPostSize = 10 * 1024 * 1024;
		String saveDirectory = "C:\\Users\\kitri\\Desktop\\spring\\cameo\\WebContent\\img\\UserImg";
		
		MultipartRequest multi = new MultipartRequest(request, saveDirectory, maxPostSize, "utf-8", new DefaultFileRenamePolicy());
		
		Enumeration formNames = multi.getFileNames();
		
		String fileInput = "";
		String fileName = "";
		String type = "";
		File fileObj = null;
		String originFileName = "";
		String fileExtend = "";
		String fileSize = "";

		while (formNames.hasMoreElements()) {
			fileInput = (String) formNames.nextElement(); // ������ǲ �̸�
			fileName = multi.getFilesystemName(fileInput); // ���ϸ�
			if (fileName != null) {
				type = multi.getContentType(fileInput); // ����ƮŸ��
				fileObj = multi.getFile(fileInput); // ���ϰ�ü
				originFileName = multi.getOriginalFileName(fileInput); // �ʱ� ���ϸ�
				fileExtend = fileName.substring(fileName.lastIndexOf(".") + 1); // ����Ȯ����
				fileSize = String.valueOf(fileObj.length()); // ����ũ��
			}
		}
		
		String exampleInputFile = "\\"+fileName;
		String inputID = multi.getParameter("inputID");
		String pwInsert = multi.getParameter("pwInsert");
		String name = multi.getParameter("name");
		String sex = multi.getParameter("sex");
		String mydate = multi.getParameter("mydate").substring(0, 10);
		String mobile = multi.getParameter("mobile");
		String email = multi.getParameter("email");
		JMember jm = new JMember(name, inputID, pwInsert, exampleInputFile, mobile, email, mydate, sex);
		int res = adminUserDB.getUserUpdate(jm);
		if (res > 0) {
			return new ModelAndView("redirect:/UserAll.sp");
		}else{
			System.out.println("����");
		}
		
		return new ModelAndView("redirect:/UserAll.sp");
	}

	@RequestMapping("/UserDelete")
	public ModelAndView UserDelete(@RequestParam(value="User_ID") String User_ID) {
		
		adminUserDB.getUserDelete(User_ID);
		
		return new ModelAndView("redirect:/UserAll.sp");
	}
}
