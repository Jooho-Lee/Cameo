package cameo.controller;

import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Enumeration;
import java.util.HashMap;

import javax.servlet.RequestDispatcher;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.oreilly.servlet.MultipartRequest;
import com.oreilly.servlet.multipart.DefaultFileRenamePolicy;

import cameo.entity.JMember;
import cameo.entity.Survey;
import cameo.biz.Login_Join_DB;
import cameo.biz.Survey_DB;

/*
@WebServlet({ "/JoinServlet", "/JoinIdCheck", "/JoinMember", "/LoginCheck", "/Survey_Input" ,"/Logout"})
*/

@Controller
public class JoinServlet {
	Login_Join_DB login_join;
	Survey_DB survey;

	@Autowired
	public JoinServlet(Login_Join_DB login_join, Survey_DB survey) {
		super();
		this.login_join = login_join;
		this.survey = survey;
	}

	@RequestMapping("/Survey_Input.sp")
	private ModelAndView Survey_Input(HttpServletRequest request, HttpServletResponse response) {
		ModelAndView mav = null;
		HttpSession session = request.getSession();
		String id = (String) session.getAttribute("user_id");
		String check = (String) request.getParameter("check");
		String feeLimit = "0";
		if (request.getParameter("annualfee") != null) {
			feeLimit = request.getParameter("annualfee");
		}
		String income = request.getParameter("income");
		String saving = "0";
		if (request.getParameter("saving") != null) {
			saving = request.getParameter("saving");
		}
		String prefer1 = request.getParameter("prefer1");
		String prefer2 = request.getParameter("prefer2");
		String prefer3 = request.getParameter("prefer3");
		String prefer4 = request.getParameter("prefer4");
		String locaion = request.getParameter("location");
		String gender = request.getParameter("sex");
		String ageGroup = request.getParameter("age");
		int cardRate = 0;
		if (request.getParameter("cardRate") != null) {
			cardRate = Integer.parseInt(request.getParameter("cardRate"));
		}
		int marriage = Integer.parseInt(request.getParameter("marry"));
		int child = Integer.parseInt(request.getParameter("child"));
		Survey su = new Survey(id, feeLimit, income, saving, prefer1, prefer2, prefer3, prefer4, locaion, gender,
				ageGroup, cardRate, marriage, child);

		int res = survey.getInsertSurvey(su);
		if (res > 0) {
			HashMap seq = login_join.getLoginSubmit(id);
			session.setAttribute("su_check", seq);
			if (check == null) {
				mav = new ModelAndView("main");
			} else {
				mav = new ModelAndView("suggestion/suggest_by_pattern");
				}
		} else {
			System.out.println("false");
		}
		
		return mav;
	}

	@RequestMapping("/LoginCheck.sp")
	private void LoginCheck(HttpServletRequest request, HttpServletResponse response) throws IOException {
		
		String id = request.getParameter("id");
		String pwd = request.getParameter("pwd");

		PrintWriter out = response.getWriter();
		JMember mem = new JMember();
		mem.setUSER_ID(id);
		mem.setUSER_PW(pwd);
		int res = login_join.getLoginCheck(mem);
		if (res > 0) {
			HashMap seq = login_join.getLoginSubmit(id);
			HttpSession session = request.getSession();
			session.setAttribute("su_check", seq);
			session.setAttribute("user_id", id);
		} else {
			out.print("not correct!");
		}
	}

	@RequestMapping("/JoinIdCheck.sp")
	private void JoinIdCheck(HttpServletRequest request, HttpServletResponse response) throws IOException {
		
		response.setContentType("text/html;charset=UTF-8");
		PrintWriter out = response.getWriter();
		String id = request.getParameter("aa");
		Connection conn = null;
		Statement stmt = null;
		ResultSet rs = null;
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			conn = DriverManager.getConnection("jdbc:oracle:thin:@192.168.0.24:1521:xe", "cameo", "cameo");
			String sql = "select user_id from user_info where user_id ='" + id + "'";
			stmt = conn.createStatement();
			rs = stmt.executeQuery(sql);
			if (rs.next()) {
				out.print("<span class='sp2'>������� ID�Դϴ�.</span>");
			} else {
				out.print("<span class='sp1'>��밡���� ID�Դϴ�.</span>");
			}
		} catch (Exception e) {
		} finally {
			try {
				if (rs != null)
					rs.close();
				if (stmt != null)
					stmt.close();
				if (conn != null)
					conn.close();
			} catch (SQLException e) {
			}
		}
	}

	@RequestMapping("/JoinMember.sp")
	private ModelAndView JoinMember(HttpServletRequest request, HttpServletResponse response) throws IOException {
		
		int maxPostSize = 10 * 1024 * 1024; // 10MB
		String saveDirectory = "C:\\Users\\kitri\\Desktop\\spring\\cameo\\WebContent\\img\\UserImg";

		MultipartRequest multi = new MultipartRequest(request, saveDirectory, maxPostSize, "UTF-8",
				new DefaultFileRenamePolicy());

		Enumeration formNames = multi.getFileNames(); // ���� �̸� ��ȯ

		String fileInput = "";
		String fileName = "";
		String type = "";
		File fileObj = null;
		String originFileName = "";
		String fileExtend = "";
		String fileSize = "";

		while (formNames.hasMoreElements()) {
			fileInput = (String) formNames.nextElement(); // ������ǲ �̸�
			fileName = multi.getFilesystemName(fileInput); // ���ϸ�
			if (fileName != null) {
				type = multi.getContentType(fileInput); // ����ƮŸ��
				fileObj = multi.getFile(fileInput); // ���ϰ�ü
				originFileName = multi.getOriginalFileName(fileInput); // �ʱ� ���ϸ�
				fileExtend = fileName.substring(fileName.lastIndexOf(".") + 1); // ����Ȯ����
				fileSize = String.valueOf(fileObj.length()); // ����ũ��
			}
		}

		String file = "\\" + fileName;
		String id = multi.getParameter("inputID");
		String pwd = multi.getParameter("pwInsert");
		String name = multi.getParameter("name");
		String sex = multi.getParameter("sex");
		String birth = multi.getParameter("mydate");
		String mobile = multi.getParameter("mobile");
		String email = multi.getParameter("email");
		JMember jm = new JMember(id, name, pwd, file, mobile, email, birth, sex);
		ModelAndView mav = new ModelAndView();
		int res = login_join.getJoinMember(jm);
		if (res > 0) {
			System.out.println("����");
			return new ModelAndView("../../index");
		} else {
			System.out.println("����");
		}
		
		return mav;
	}
	@RequestMapping("/Logout.sp")
	private ModelAndView Logout(HttpServletRequest request, HttpServletResponse response) throws IOException {
		HttpSession session = request.getSession();
		if(session !=null){
			session.invalidate();
		}
		ModelAndView mav = new ModelAndView("../../index");
		return mav;
	}
}
