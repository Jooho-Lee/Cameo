package cameo.controller;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import cameo.entity.*;
import cameo.biz.*;
import cameo.util.*;

@Controller
public class BoardController extends HttpServlet {
	
	BoardManager boardManager;

	@Autowired
	public BoardController(BoardManager boardManager){
		
		super();
		this.boardManager = boardManager;
	}

	@RequestMapping("/board.sp")
	private ModelAndView execute(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		ModelAndView mav = null;
		
		String root = request.getContextPath();
		String act = request.getParameter("act");
		int pg = NumberCheck.nullToOne(request.getParameter("pg"));
		String key = StringCheck.nullToBlank(request.getParameter("key"));
		String word = Encoder.isoToEuc(StringCheck.nullToBlank(request.getParameter("word")));
		
		ArrayList<Object> qs = new ArrayList<Object>();
		qs.add(pg);
		qs.add(key);
		qs.add(Encoder.urlEncode(word));
		
		boolean flag = true;

		if ("mvnew".equals(act)) {
			mav = new ModelAndView("/board/write","qs", qs);
			flag=false;
			//�۵��
		} else if ("newwrite".equals(act)) {

			//////////////// session���� �ۼ��� ���� ��� //////////////
			HttpSession session = request.getSession();
			String id = (String)session.getAttribute("user_id");

			BoardDTO boardDTO = new BoardDTO();
			boardDTO.setUser_id(id);
			boardDTO.setSubject(request.getParameter("subject"));
			boardDTO.setContent(request.getParameter("content"));
			int seq = boardManager.writeArticle(boardDTO);
			if (seq != 0){
				qs.add(seq);
				mav = new ModelAndView("/board/QnA","qs",qs);
			}
			else{
				mav = new ModelAndView("/board/writeFail","qs",qs);
			}flag=false;
		} else if ("mvreply".equals(act)) {
			int seq = NumberCheck.nullToZero(request.getParameter("seq"));
			BoardDTO boardDTO = boardManager.getArticle(seq, 1);// ��ۿ� ����
																	// ��������.
			request.setAttribute("replyArticle", boardDTO);
			flag = false;
			mav= new ModelAndView("board/reply","qs",qs);
		} else if ("replywrite".equals(act)) {
			//////////////// session���� �ۼ��� ���� ��� //////////////
			HttpSession session = request.getSession();
			String user_id = (String) session.getAttribute("user_id");

			BoardDTO boardDTO = new BoardDTO();
			boardDTO.setUser_id(user_id);
			boardDTO.setSubject(request.getParameter("subject"));
			boardDTO.setContent(request.getParameter("content"));
			boardDTO.setRef(NumberCheck.nullToZero(request.getParameter("ref")));
			boardDTO.setStep(NumberCheck.nullToZero(request.getParameter("step"))+1);
			boardDTO.setLev(NumberCheck.nullToZero(request.getParameter("lev"))+1);
			boardDTO.setP_seq(NumberCheck.nullToZero(request.getParameter("pseq")));

			int seq = boardManager.replyArticle(boardDTO);

			if (seq != 0){
				qs.add(seq);
				flag=false;
				mav = new ModelAndView("board/QnA","qs",qs);
			}
				
			else{
				flag=false;
				mav = new ModelAndView("board/writeFail","qs",qs);
			}
		} else if ("view".equals(act)) {
			int seq = NumberCheck.nullToZero(request.getParameter("seq"));
			BoardDTO boardDTO = null;
			if (seq != 0)
				boardDTO = boardManager.getArticle(seq, 0);
			request.setAttribute("viewArticle", boardDTO);
			flag = false;
			mav = new ModelAndView("board/view","qs",qs);
		} else if ("list".equals(act)) {
			//�Խ��� ���� ��´�.
			List<BoardDTO> boardlist = boardManager.getList(pg, key, word);
			request.setAttribute("boardList", boardlist);
			//�� ���� �������°�
			PageNavi pageNavi = boardManager.getPageNavi(pg, key, word);
			request.setAttribute("pageNavi", pageNavi);
			flag = false;
			mav = new ModelAndView("board/QnA","qs", qs);
		}

		else if ("modify".equals(act)) {
			int seq = NumberCheck.nullToZero(request.getParameter("seq"));
			BoardDTO boardDTO = boardManager.getArticle(seq, 1);// ������ ����
																	// ��������.
			request.setAttribute("modify", boardDTO);
			flag = false;
			mav= new ModelAndView("board/modify","qs",qs);
		} else if ("modifyarticle".equals(act)) {
			int seq = NumberCheck.nullToZero(request.getParameter("seq"));
			BoardDTO boardDTO = new BoardDTO();
			boardDTO.setSubject(request.getParameter("subject"));
			boardDTO.setContent(request.getParameter("content"));
			boardDTO.setQ_seq(seq);
			boardManager.modifyArticle(boardDTO);
			flag = false;
			mav= new ModelAndView("board/QnA","qs",qs);
		} else if ("delete".equals(act)) {
			int seq = NumberCheck.nullToZero(request.getParameter("seq"));
			int a = boardManager.deleteArticle(seq);
			if (a > 0) {
				flag=false;
				mav=new ModelAndView("board/QnA","qs",qs);
			}
		}
		if (flag){
			mav = new ModelAndView("../../index");
		}
		return mav;
	}
}