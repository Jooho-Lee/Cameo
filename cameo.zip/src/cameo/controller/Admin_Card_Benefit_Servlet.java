package cameo.controller;

import java.io.File;
import java.io.IOException;
import java.util.Enumeration;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.oreilly.servlet.MultipartRequest;
import com.oreilly.servlet.multipart.DefaultFileRenamePolicy;

import cameo.biz.Admin_Card_Benefit_DB;
import cameo.entity.Card_Benefit;

@Controller
public class Admin_Card_Benefit_Servlet {
	Admin_Card_Benefit_DB admin_Card_Benefit_DB;
	Logger log = Logger.getLogger(this.getClass());
	@Autowired
	public Admin_Card_Benefit_Servlet(Admin_Card_Benefit_DB admin_Card_Benefit_DB) {
		super();
		this.admin_Card_Benefit_DB = admin_Card_Benefit_DB;
	}

	@RequestMapping("/BenefitDelete.sp")
	public ModelAndView BenefitDelete(@RequestParam(value = "Ben_Seq") int ben_Seq) {
		boolean res = admin_Card_Benefit_DB.BenefitDelete(ben_Seq);
		ModelAndView mav = null;
		if (res = true) {
			List<Card_Benefit> list = admin_Card_Benefit_DB.listCard();
			mav = new ModelAndView("redirect:./BenefitAll.sp");
		}
		
		return mav;
	}

	@RequestMapping(value = "/BenefitUpdate.sp", method = RequestMethod.POST)
	public ModelAndView BenefitUpdate(HttpServletRequest request, HttpServletResponse response) throws IOException {
		int Ben_Seq = Integer.parseInt(request.getParameter("Ben_Seq"));
		int Usage_Result = Integer.parseInt(request.getParameter("Usage_Result"));
		
		String[] str = new String[20];
		String bsp;
		String bwp;
		String b;
		for(int i=0;i<str.length;i++){
			bsp=request.getParameter("selectSP"+(i+1));
			bwp=request.getParameter("selectWP"+(i+1));
			b = request.getParameter("ben"+(i+1));
			str[i]=bsp.concat("^"+bwp+"^"+b);
		}

		Card_Benefit benefit = new Card_Benefit(Ben_Seq,Usage_Result, str[0], str[1], str[2], str[3], str[4], str[5], str[6], str[7],
				str[8], str[9], str[10], str[11], str[12], str[13], str[14], str[15], str[16], str[17], str[18], str[19]);

		admin_Card_Benefit_DB.BenefitUpdate(benefit);

		return new ModelAndView("redirect:./BenefitAll.sp");
	}

	@RequestMapping("/BenefitFind.sp")
	public ModelAndView BenefitFind(@RequestParam(value = "Ben_Seq") int Ben_Seq) {
		Card_Benefit res = admin_Card_Benefit_DB.BenefitFind(Ben_Seq);
		return new ModelAndView("admin_page/BenefitUpdate", "find", res);
	}

	@RequestMapping("/CardDelete.sp")
	public ModelAndView deleteCard(@RequestParam(value = "Card_Seq") int card_seq) {
		boolean res = admin_Card_Benefit_DB.deleteCard(card_seq);
		ModelAndView mav = null;

		if (res = true) {
			List<Card_Benefit> list = admin_Card_Benefit_DB.listCard();
			mav = new ModelAndView("admin_page/CardAll", "all", list);
		}
		
		return mav;
	}
	
	@RequestMapping("/CardFind.sp")
	public ModelAndView findCard(@RequestParam(value = "Card_Seq") int card_seq) {
		Card_Benefit res = admin_Card_Benefit_DB.findCard(card_seq);
		
		return new ModelAndView("/admin_page/CardUpdate", "find", res);
	}

	@RequestMapping(value = "/CardUpdate.sp", method = RequestMethod.POST)
	public ModelAndView updateCard(HttpServletRequest request, HttpServletResponse response) throws IOException {
		int maxPostSize = 10 * 1024 * 1024; // 10MB
		String saveDirectory = "C:\\Users\\kitri\\Desktop\\spring\\cameo\\WebContent\\img\\CardImg";

		MultipartRequest multi = new MultipartRequest(request, saveDirectory, maxPostSize, "utf-8",
				new DefaultFileRenamePolicy());
		Enumeration formNames = multi.getFileNames(); // ���� �̸� ��ȯ

		String fileInput = "";
		String fileName = "";
		String type = "";
		File fileObj = null;
		String originFileName = "";
		String fileExtend = "";
		String fileSize = "";

		while (formNames.hasMoreElements()) {
			fileInput = (String) formNames.nextElement(); // ������ǲ �̸�
			fileName = multi.getFilesystemName(fileInput); // ���ϸ�
			if (fileName != null) {
				type = multi.getContentType(fileInput); // ����ƮŸ��
				fileObj = multi.getFile(fileInput); // ���ϰ�ü
				originFileName = multi.getOriginalFileName(fileInput); // �ʱ� ���ϸ�
				fileExtend = fileName.substring(fileName.lastIndexOf(".") + 1); // ����Ȯ����
				fileSize = String.valueOf(fileObj.length()); // ����ũ��
			}
		}
		int Card_Seq = Integer.parseInt(multi.getParameter("Card_Seq"));

		String og_file = multi.getParameter("OG_File");
		
		String Card_Name = multi.getParameter("Card_Name");
		String Card_Type = multi.getParameter("Card_Type");
		String Card_Corp = multi.getParameter("Card_Corp");
		int AnnualFee = Integer.parseInt(multi.getParameter("AnnualFee"));
		String Card_Image = "\\" + fileName;
		//���� �̹����� �� �̹��� ���� �ڵ� �ʿ�
		Card_Benefit c_entity = new Card_Benefit(Card_Seq, Card_Name, Card_Type, Card_Corp, Card_Image, AnnualFee);

		boolean res = admin_Card_Benefit_DB.updateCard(c_entity);

		ModelAndView mav = null;

		if (res = true) {
			mav = new ModelAndView("redirect:/CardAll.sp");
		}
		
		return mav;
	}

	@RequestMapping(value = "/BenefitAdd.sp", method = RequestMethod.POST)
	private ModelAndView BenefitInsert(HttpServletRequest request, HttpServletResponse response) throws IOException {
		int maxPostSize = 10 * 1024 * 1024; // 10MB
		String saveDirectory = "C:\\Users\\kitri\\Desktop\\spring\\cameo\\WebContent\\img\\CardImg";

		MultipartRequest multi = new MultipartRequest(request, saveDirectory, maxPostSize, "utf-8",
				new DefaultFileRenamePolicy());
		
		/*int Ben_Seq = Integer.parseInt(request.getParameter("Ben_Seq"));*/
		int Usage_Result = Integer.parseInt(multi.getParameter("Usage_Result"));
		String[] str = new String[20];
		String bsp;
		String bwp;
		String b;
		for(int i=0;i<str.length;i++){
			bsp=multi.getParameter("selectSP"+(i+1));
			bwp=multi.getParameter("selectWP"+(i+1));
			b = multi.getParameter("ben"+(i+1));
			str[i]=bsp.concat("^"+bwp+"^"+b);
		}
		
		Card_Benefit benefit = new Card_Benefit(Usage_Result, str[0], str[1], str[2], str[3], str[4], str[5], str[6], str[7],
				str[8], str[9], str[10], str[11], str[12], str[13], str[14], str[15], str[16], str[17], str[18],
				str[19]);

		admin_Card_Benefit_DB.insertBenefit(benefit);//����

		return new ModelAndView("redirect:./BenefitAll.sp");
	}

	@RequestMapping(value = "/CardInsert.sp", method = RequestMethod.POST)
	public ModelAndView insertCard(HttpServletRequest request, HttpServletResponse response)
					throws IOException {
		
		int maxPostSize = 10 * 1024 * 1024; // 10MB
		String saveDirectory = "C:\\Users\\kitri\\Desktop\\spring\\cameo\\WebContent\\img\\CardImg";

		MultipartRequest multi = new MultipartRequest(request, saveDirectory, maxPostSize, "utf-8",
				new DefaultFileRenamePolicy());

		Enumeration formNames = multi.getFileNames(); // ���� �̸� ��ȯ

		String fileInput = "";
		String fileName = "";
		String type = "";
		File fileObj = null;
		String originFileName = "";
		String fileExtend = "";
		String fileSize = "";

		while (formNames.hasMoreElements()) {
			fileInput = (String) formNames.nextElement(); // ������ǲ �̸�
			fileName = multi.getFilesystemName(fileInput); // ���ϸ�
			if (fileName != null) {
				type = multi.getContentType(fileInput); // ����ƮŸ��
				fileObj = multi.getFile(fileInput); // ���ϰ�ü
				originFileName = multi.getOriginalFileName(fileInput); // �ʱ� ���ϸ�
				fileExtend = fileName.substring(fileName.lastIndexOf(".") + 1); // ����Ȯ����
				fileSize = String.valueOf(fileObj.length()); // ����ũ��
			}
		}

		String Card_Image = "\\" + fileName;
		
		String Card_Name = multi.getParameter("Card_Name");
		String Card_Type = multi.getParameter("Card_Type");
		String Card_Corp = multi.getParameter("Card_Corp");
		int AnnualFee = Integer.parseInt(multi.getParameter("AnnualFee"));
		
		
		Card_Benefit card = new Card_Benefit(Card_Name, Card_Type, Card_Corp, Card_Image, AnnualFee);

		boolean res_c = admin_Card_Benefit_DB.insertCard(card);
		
		int Usage_Result = Integer.parseInt(multi.getParameter("Usage_Result"));

		String[] str = new String[20];
		String bsp;
		String bwp;
		String b;
		for (int i = 0; i < str.length; i++) {
			bsp = multi.getParameter("selectSP" + (i + 1));
			bwp = multi.getParameter("selectWP" + (i + 1));
			b = multi.getParameter("ben" + (i + 1));
			str[i] = bsp.concat("^" + bwp + "^" + b);
		}
		Card_Benefit benefit = new Card_Benefit(Usage_Result, str[0], str[1], str[2], str[3], str[4], str[5], str[6],
				str[7], str[8], str[9], str[10], str[11], str[12], str[13], str[14], str[15], str[16], str[17], str[18],
				str[19]);

		boolean res_b = admin_Card_Benefit_DB.insertBenefit(benefit);

		ModelAndView mav = null;

		if (res_c = true) {
			List<Card_Benefit> list = admin_Card_Benefit_DB.listCard();// ���� ��
			mav = new ModelAndView("/admin_page/CardAll", "all", list);
		}

		return mav;
	}

	@RequestMapping("/PagePath.sp")
	private ModelAndView PagePath(@RequestParam(value="path") String path) {
		if (path.equals("UserAll")) {
			return new ModelAndView("redirect:./UserAll.sp");
		} else if (path.equals("CardMain")) {
			return new ModelAndView("/admin_page/CardMain");
		} else if (path.equals("NoticeAll")) {
			return new ModelAndView("redirect:./NoticeAll.sp");
		} else if (path.equals("Analysis")) {
			return new ModelAndView("/admin_page/Analysis");
		}
		
		return new ModelAndView("/admin_page/BoardMain");
	}

	@RequestMapping("/BenefitAll.sp")
	private ModelAndView BenefitAll() {
		List<Card_Benefit> res = admin_Card_Benefit_DB.BenefitAll();
		ModelAndView mav = new ModelAndView("/admin_page/BenefitAll", "all", res);

		return mav;
	}

	@RequestMapping("/CardAll.sp")
	public ModelAndView listCard() {
		List<Card_Benefit> list = admin_Card_Benefit_DB.listCard();
		ModelAndView mav = new ModelAndView("/admin_page/CardAll", "all", list);

		return mav;
	}
}
