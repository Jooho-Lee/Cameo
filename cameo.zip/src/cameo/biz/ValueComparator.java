package cameo.biz;

import java.util.Comparator;
import java.util.HashMap;
import java.util.Map;

public class ValueComparator implements Comparator<Integer> {

	Map<Integer, Integer> seqBen;
	Map<Integer, Integer> seqBen1;


	public ValueComparator(Map<Integer, Integer> seqBen, Map<Integer, Integer> seqBen1) {
		this.seqBen = seqBen;
		this.seqBen1 = seqBen1;
	}

	public ValueComparator(HashMap<Integer, Integer> seqBen) {
		this.seqBen = seqBen;
		
	}

	public int compare(Integer a, Integer b) {
		if (seqBen.get(a) >= seqBen.get(b)) {
			return 1;
		}else {
			return -1;
		} 
	}
	
	public int compare(Integer a, Integer b, Integer c, Integer d) {
		if (seqBen.get(a) > seqBen.get(b)) {
			return 1;
		}else if(seqBen.get(a) == seqBen.get(b)) {
			if(seqBen1.get(a)>=seqBen.get(b)){
				return 1;
			}else{
				return -1;
			}
		} else{
			return -1;
		}
	}


	
}
