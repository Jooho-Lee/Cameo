package cameo.biz;

public class BenAvg {

	private String ben;

	public BenAvg(String ben) {
		this.ben = ben;
	}

	
	public int getBenAvg() {
		int avg=0;
		if (ben.equals("ben1") || ben.equals("ben9")) {
			avg=1500;
		}else if(ben.equals("ben2") || ben.equals("ben4") || ben.equals("ben5")
				|| ben.equals("ben11")|| ben.equals("ben14") || ben.equals("ben19")){
			avg=50000;
		}else if(ben.equals("ben3")){
			avg=80000;
		}else if(ben.equals("ben6") || ben.equals("ben8") || ben.equals("ben17")){
			avg=20000;
		}else if(ben.equals("ben7") || ben.equals("ben16") || ben.equals("ben12") || ben.equals("ben20")){
			avg=10000;
		}else if(ben.equals("ben10")){
			avg=60000;
		}else if(ben.equals("ben13")){
			avg=100000;
		}else if(ben.equals("ben15")){
			avg=30000;
		}else if(ben.equals("ben18")){
			avg=80000;
		}
		return avg;
	}

}
