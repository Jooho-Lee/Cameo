package cameo.biz;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import cameo.dao.AdminUserDao;
import cameo.entity.JMember;

@Service("adminUserService")
public class Admin_User_DB {

	private AdminUserDao amdinUserDao;
	
	@Autowired
	public Admin_User_DB(AdminUserDao amdinUserDao) {
		super();
		this.amdinUserDao = amdinUserDao;
	}

	public List<JMember> getUserAll() {
		List<JMember> r = amdinUserDao.getUserAll();
		return r;
	}

	public JMember getUserFind(String User_ID) {
		JMember r = amdinUserDao.getUserFind(User_ID);
		return r;
	}

	public int getUserUpdate(JMember jm) {
		int r = amdinUserDao.getUserUpdate(jm);
		return r;
	}

	public int getUserDelete(String User_ID) {
		int r = amdinUserDao.getUserDelete(User_ID);
		return r;
	}
}
