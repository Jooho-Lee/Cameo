package cameo.biz;

import java.util.HashMap;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import cameo.dao.MemberDao;
import cameo.entity.JMember;

@Service("joinService")
public class Login_Join_DB {

	private MemberDao memDao;

	@Autowired
	public Login_Join_DB(MemberDao memDao) {
		super();
		this.memDao = memDao;
	}

	public int getJoinMember(JMember jm) {
		return memDao.MemberInsert(jm);
	}

	public int getLoginCheck(JMember jm) {
		return memDao.LoginCheck(jm);
	}

	public HashMap getLoginSubmit(String id) {
		return memDao.LoginSubmit(id);
	}
}
