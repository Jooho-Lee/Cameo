package cameo.biz;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import cameo.dao.AdminBoardDao;
import cameo.entity.Notice;

@Service("AdminBoardDB")
public class Admin_Board_DB {
	private AdminBoardDao boardDao;
	
	@Autowired
	public Admin_Board_DB(AdminBoardDao boardDao) {
		super();
		this.boardDao = boardDao;
	}

	public boolean NoticeInsert(Notice ntc){
		return boardDao.NoticeInsert(ntc);
	}
		
	public List<Notice> NoticeAll(){
		return boardDao.NoticeAll();
	}
	
	public Notice NoticeFind(int notice_Seq){
		return boardDao.NoticeFind(notice_Seq);
	}
	
	public boolean NoticeUpdate(Notice ntc) {
		return boardDao.NoticeUpdate(ntc);
	}
	
	public boolean NoticeDelete(int notice_Seq){
		return boardDao.NoticeDelete(notice_Seq);
	}
}
