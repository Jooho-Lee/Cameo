package cameo.biz;

import java.util.HashMap;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import cameo.dao.SurveyDao;
import cameo.entity.*;
import cameo.util.SurvetTransformVer2;

@Service("surveyService")
public class Survey_DB {
	private SurveyDao surveyDao;
	
	@Autowired
	public Survey_DB(SurveyDao surveyDao){
		super();
		this.surveyDao=surveyDao;
	}
	
	public int getInsertSurvey(Survey su) {
		return surveyDao.SurveyInsert(su);
	}

	public HashMap getSurveyAll(int su_seq) {
		HashMap SurveyAll =surveyDao.getSurveyAll(su_seq);
	      System.out.println(SurveyAll);
	      SurvetTransformVer2 st = new SurvetTransformVer2();
	      SurveyAll.replace("PREFER1", st.Transform_Text(SurveyAll).get("PREFER1"));
	      SurveyAll.replace("PREFER2", st.Transform_Text(SurveyAll).get("PREFER2"));
	      SurveyAll.replace("PREFER3", st.Transform_Text(SurveyAll).get("PREFER3"));
	      SurveyAll.replace("PREFER4", st.Transform_Text(SurveyAll).get("PREFER4"));
	      SurveyAll.replace("CHILD", st.Transform_Text(SurveyAll).get("CHILD"));
	      SurveyAll.replace("LOCATION", st.Transform_Text(SurveyAll).get("LOCATION"));
	      SurveyAll.replace("GENDER", st.Transform_Text(SurveyAll).get("GENDER"));
	      if(SurveyAll.get("MARRIAGE").equals("1")){
	         SurveyAll.replace("MARRIAGE", "Done");
	      }else{
	         SurveyAll.replace("MARRIAGE", "Not");
	      }
	      return SurveyAll;
	}
}
