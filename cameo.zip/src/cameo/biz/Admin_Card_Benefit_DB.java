package cameo.biz;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import cameo.dao.AdminCardBenefitDao;
import cameo.entity.Card_Benefit;

@Service("AdminCardBenefitDB")
public class Admin_Card_Benefit_DB {
	private AdminCardBenefitDao cardbenefitDao;

	@Autowired
	public Admin_Card_Benefit_DB(AdminCardBenefitDao cardbenefitDao) {
		super();
		this.cardbenefitDao = cardbenefitDao;
	}

	public List<Card_Benefit> listCard() {
		return cardbenefitDao.listCard();
	}

	public Card_Benefit findCard(int card_seq) {
		return cardbenefitDao.findCard(card_seq);
	}

	public boolean insertCard(Card_Benefit c_entity) {
		return cardbenefitDao.insertCard(c_entity);
	}

	public boolean insertBenefit(Card_Benefit benefit) {

		return cardbenefitDao.insertBenefit(benefit);
	}

	public boolean updateCard(Card_Benefit c_entity) {

		return cardbenefitDao.updateCard(c_entity);
	}

	public boolean deleteCard(int card_seq) {

		return cardbenefitDao.deleteCard(card_seq);
	}

	public List<Card_Benefit> BenefitAll() {

		return cardbenefitDao.BenefitAll();
	}

	public Card_Benefit BenefitFind(int ben_Seq) {

		return cardbenefitDao.BenefitFind(ben_Seq);
	}

	public boolean BenefitUpdate(Card_Benefit b_entity) {

		return cardbenefitDao.BenefitUpdate(b_entity);
	}

	public boolean BenefitDelete(int ben_Seq) {

		return cardbenefitDao.BenefitDelete(ben_Seq);
	}
}
