package cameo.biz;

import java.util.HashMap;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import cameo.util.*;
import cameo.dao.*;
import cameo.entity.*;

@Service("boardService")
public class BoardManager {

	private BoardDAO boardDAO;
	
	@Autowired
	public BoardManager(BoardDAO boardDAO){
		super();
		this.boardDAO=boardDAO;
	}
	


	public int writeArticle(BoardDTO boardDTO) {
		return boardDAO.writeArticle(boardDTO);
	}

	public BoardDTO getArticle(int seq, int func) {
		if (func == 0){
			boardDAO.updatHit(seq);
		}
		BoardDTO boardDTO = boardDAO.getArticle(seq);
		
		return boardDTO;
	}

	public List<BoardDTO> getList(int pg, String key, String word) {
		int end = pg * PageSize.BOARD_LIST_SIZE;
		int start = end - PageSize.BOARD_LIST_SIZE;

		HashMap<String, Object> map = new HashMap<String, Object>();
		map.put("end", end);
		map.put("start",start);
		map.put("key", key);
		map.put("word", word);
		return boardDAO.getList(map);
	}

	public PageNavi getPageNavi(int pg, String key, String word) {
		PageNavi pageNavi = new PageNavi();
		
		HashMap<String, Object> map = new HashMap<String, Object>();
		map.put("key", key);
		map.put("word", word);
		
		int totalArticle = boardDAO.getTotalArticleCount(map);
		pageNavi.setTotalArticle(totalArticle);
		int listSize = 0;
		listSize = PageSize.BOARD_LIST_SIZE;
		int totalPage = (totalArticle + (listSize - 1)) / listSize;
		pageNavi.setTotalPage(totalPage);
		pageNavi.setPageNo(pg);
		pageNavi.setNowFirst(pg <= PageSize.PAGE_SIZE);
		pageNavi.setNowEnd((((totalPage - 1) / PageSize.PAGE_SIZE) * PageSize.PAGE_SIZE + 1) <= pg ? true : false);
		int newArticleCount = boardDAO.getNewArticleCount(1);
		pageNavi.setNewArticleCount(newArticleCount);
		return pageNavi;
	}

	public int replyArticle(BoardDTO boardDTO) {
		return boardDAO.replyArticle(boardDTO);
	}

	public int modifyArticle(BoardDTO boardDTO) {

		return boardDAO.modifyArticle(boardDTO);
	}

	public int deleteArticle(int seq) {

		return boardDAO.deleteArticle(seq);
	}

}
