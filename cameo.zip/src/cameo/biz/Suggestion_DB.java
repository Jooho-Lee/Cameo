package cameo.biz;


import java.sql.Connection;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Set;
import java.util.TreeMap;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import cameo.dao.CardDao;


@Service("suggestion")
public class Suggestion_DB {

	private CardDao cardDao;
	
	
	@Autowired
	public Suggestion_DB(CardDao cardDao) {
		super();
		this.cardDao = cardDao;
	}

	public ArrayList getSuggestSaving(ArrayList card) {
		ArrayList<String[]> bensugg = cardDao.getSuggestSaving(card);
		return bensugg;
	}

	public ArrayList getSortBen1(ArrayList toSavingSort) {
		ArrayList sortBen1 = cardDao.getSortBen1(toSavingSort);
		return sortBen1;
	}
	
	public ArrayList getSavingSort(ArrayList bensugg, String benefit1) {
		HashMap<Integer, Integer> seqBen = new HashMap<Integer, Integer>();
		ValueComparator bvc = new ValueComparator(seqBen);
		TreeMap<Integer, Integer> seqBenSort = new TreeMap<Integer, Integer>(bvc);
		
		ArrayList sortSeqRes = new ArrayList<>();
		
		for (int i = 0; i < bensugg.size(); i++) {
			HashMap<String, String> temp = (HashMap<String, String>) bensugg.get(i);
			
			ArrayList benCalc = new ArrayList<>(temp.values());
			
			String bene1 = String.valueOf(benCalc.get(temp.size()-2));
			String[] ben1 = bene1.split("\\^");
			int seq = Integer.valueOf(String.valueOf(benCalc.get(temp.size()-1)));

			BenAvg ba = new BenAvg(benefit1);
			int benAvg = ba.getBenAvg();
			int calcBen1; 
			
			if (ben1[1].equals("0")) {
				calcBen1 = benAvg - Integer.parseInt(ben1[2]);
			} else {
				calcBen1 = (int) (benAvg - (benAvg * (Double.parseDouble(ben1[2])/100)));
			}
			seqBen.put(seq, calcBen1);
		}
		seqBenSort.putAll(seqBen);
		Set<Integer> seqSet = seqBenSort.keySet();
		Iterator itr = seqSet.iterator();
		while (itr.hasNext()) {
			int seq = (int) itr.next();
			sortSeqRes.add(seq);

		}
		return sortSeqRes;
	}

	public ArrayList getSavingSortMix(ArrayList bensuggMix, String benefit1, String benefit2) {
		HashMap<Integer, Integer> seqBenMix = new HashMap<Integer, Integer>();
		ValueComparator bvc = new ValueComparator(seqBenMix);
		TreeMap<Integer, Integer> seqBenSortMix = new TreeMap<Integer, Integer>(bvc);

		ArrayList sortSeqMixRes = new ArrayList<>();
		int calcBen1;
		int calcBen2;
		
		BenAvg ba = new BenAvg(benefit1);
		BenAvg ba2 = new BenAvg(benefit2);
		int benAvg = ba.getBenAvg();
		int benAvg2 = ba2.getBenAvg();

		//���� ����
		for (int i = 0; i < bensuggMix.size(); i++) {
			HashMap<String, String> temp = (HashMap<String, String>) bensuggMix.get(i);
			ArrayList benCalc = new ArrayList<>(temp.values());
			
			int seq = Integer.valueOf(String.valueOf(benCalc.get(temp.size()-1)));
			
			String bene1 = String.valueOf(benCalc.get(temp.size()-2));
			String[] ben1 = bene1.split("\\^");
			
			if(ben1.length==3){
				if (ben1[1].equals("0")) {
					calcBen1 = benAvg - Integer.parseInt(ben1[2]);
				} else {
					calcBen1 = (int) (benAvg - (benAvg * (Double.parseDouble(ben1[2])/100)));
				}
			} else{
				calcBen1 = benAvg - 0;
			}

			String bene2 = String.valueOf(benCalc.get(temp.size()-3));
			String[] ben2 = bene2.split("\\^");
			
			if(ben2.length==3){
				if (ben2[1].equals("0")) {
					calcBen2 = benAvg2 - Integer.parseInt(ben2[2]);
				} else {
					calcBen2 = (int) (benAvg -(benAvg2 * (Double.parseDouble(ben2[2])/100)));
				}
			} else{
				calcBen2 = benAvg - 0;
			}
			
			seqBenMix.put(seq, ((calcBen1 + calcBen2) / 2));
		}

		seqBenSortMix.putAll(seqBenMix);

		Set<Integer> seqSet = seqBenSortMix.keySet();
		Iterator itr = seqSet.iterator();
		while (itr.hasNext()) {
			int seq = (int) itr.next();
			sortSeqMixRes.add(seq);
		}
		return sortSeqMixRes;
	}

	public ArrayList getBenSplit(ArrayList sortBen1) {
		ArrayList splitResult = new ArrayList();

		for (int i = 0; i < sortBen1.size(); i++) {
			HashMap<String, String> splitBen = (HashMap<String, String>) sortBen1.get(i);
			ArrayList splitRes = new ArrayList();
			ArrayList beneTp = new ArrayList();

			String card_name = splitBen.get("CARD_NAME");
			String card_type = splitBen.get("CARD_TYPE");
			String card_corp = splitBen.get("CARD_CORP");
			String card_image = splitBen.get("CARD_IMAGE");
			String annualfee = String.valueOf(splitBen.get("ANNUALFEE"));
			String usage_result = String.valueOf(splitBen.get("USAGE_RESULT"));
			
			splitRes.add(card_name);
			splitRes.add(card_type);
			splitRes.add(card_corp);
			splitRes.add(card_image);
			splitRes.add(annualfee);
			splitRes.add(usage_result);
			
			
			for (int j = 1; j <= 20; j++) {
				String temp = splitBen.get("BEN"+j);
				String[] splitB = temp.split("\\^");
				if (splitB.length == 3) {
					splitRes.add(splitB[2]);
					beneTp.add(splitB[1]);
				} else if (splitB.length == 2) {
					splitRes.add(splitB[1]);
					beneTp.add(splitB[0]);
				}
				
				
			}
			splitResult.add(splitRes);
			splitResult.add(beneTp);
		}
		
		return splitResult;
	}

	
	public ArrayList SuggestPattern(HashMap survey) {
		ArrayList surveyCard = cardDao.SuggestPattern(survey);
		return surveyCard;
	}

	public ArrayList getSavingSort(ArrayList surveyCard, String prefer1, String prefer2) {
	      HashMap<Integer, Integer> seqBen1 = new HashMap<Integer, Integer>();
	      ValueComparator bvc = new ValueComparator(seqBen1);
	      TreeMap<Integer, Integer> seqBen1Sort = new TreeMap<Integer, Integer>(bvc);
	      ArrayList sortBen1Res = new ArrayList<>();

	      BenAvg ba = new BenAvg(prefer1);
	      int benAvg = ba.getBenAvg();
	      int calcBen1 = 0;
	      

	      //1����
	      for (int i = 0; i < surveyCard.size(); i++) {
	         HashMap<String, String> temp = (HashMap<String, String>) surveyCard.get(i);
	         
	         ArrayList benCalc = new ArrayList<>(temp.values());
	         
	         String bene1 = (String) benCalc.get(temp.size()-2);
	         String[] ben1 = bene1.split("\\^");
	         int seq = Integer.valueOf(String.valueOf(benCalc.get(temp.size()-1)));
	         
	         

	         if (ben1[1].equals("0")) {
	            calcBen1 = benAvg - Integer.parseInt(ben1[2]);
	         } else {
	            calcBen1 = (int) (benAvg - (benAvg * (Double.parseDouble(ben1[2])/100)));
	         }

	         seqBen1.put(seq, calcBen1);
	      }
	      seqBen1Sort.putAll(seqBen1);
	      
	      Set<Integer> seqSet = seqBen1Sort.keySet();
	      Iterator itr = seqSet.iterator();
	      while (itr.hasNext()) {
	         int seq = (int) itr.next();
	         sortBen1Res.add(seq);
	      }
	      
	      //2����
	      HashMap<Integer, Integer> seqBen2 = new HashMap<Integer, Integer>();
	      ValueComparator bvc2 = new ValueComparator(seqBen2);
	      TreeMap<Integer, Integer> seqBen2Sort = new TreeMap<Integer, Integer>(bvc);
	      ArrayList sortBen2Res = new ArrayList<>();

	      BenAvg ba2 = new BenAvg(prefer1);
	      int ben2Avg = ba.getBenAvg();
	      int calcBen2 = 0;
	      int cnt = 20;
	      
	      if(surveyCard.size()<cnt){
	         cnt = surveyCard.size();
	      }
	         
	      for (int i = 0; i < cnt; i++) {
	         HashMap<String, String> temp = (HashMap<String, String>) surveyCard.get(i);
	         
	         ArrayList benCalc = new ArrayList<>(temp.values());
	         
	         String bene2 = (String) benCalc.get(temp.size()-3);
	         String[] ben2 = bene2.split("\\^");
	         int seq = Integer.valueOf(String.valueOf(benCalc.get(temp.size()-1)));
	         
	         if (ben2[1].equals("0")) {
	            calcBen2 = benAvg - Integer.parseInt(ben2[2]);
	         } else {
	            calcBen2 = (int) (benAvg - (benAvg * (Double.parseDouble(ben2[2])/100)));
	         }

	         seqBen2.put(seq, ((calcBen1 + calcBen2) / 2));
	      }
	      seqBen2Sort.putAll(seqBen2);
	      
	      
	      
	      Set<Integer> seqSet2 = seqBen2Sort.keySet();
	      Iterator itr2 = seqSet2.iterator();
	      ArrayList seqAr = new ArrayList();
	      while (itr2.hasNext()) {
	         int seq = (int) itr2.next();
	         seqAr.add(seq);
	      }
	      ArrayList ben2SeqTem = new ArrayList();
	      for(int i=0; i<seqAr.size()-1;i++){
	         
	         int a = seqBen2.get(seqAr.get(i));
	         int b = seqBen2.get(seqAr.get(i+1));
	         int c = seqBen1.get(seqAr.get(i));
	         int d = seqBen1.get(seqAr.get(i+1));
	   
	         if(a!=b){
	            ben2SeqTem.add(seqAr.get(i));
	         }else{
	            if(c>b){
	               ben2SeqTem.add(seqAr.get(i));
	            }else{
	               ben2SeqTem.add(seqAr.get(i+1));
	            }
	         }
	      
	      }
	      return ben2SeqTem;
	   }

	   public ArrayList getSavingSort(ArrayList surveyCard, String prefer1, String prefer2, String prefer3) {
	      HashMap<Integer, Integer> seqBen1 = new HashMap<Integer, Integer>();
	      ValueComparator bvc = new ValueComparator(seqBen1);
	      TreeMap<Integer, Integer> seqBen1Sort = new TreeMap<Integer, Integer>(bvc);
	      ArrayList sortBen1Res = new ArrayList<>();

	      BenAvg ba = new BenAvg(prefer1);
	      int benAvg = ba.getBenAvg();
	      int calcBen1 = 0;
	      

	      //1����
	      for (int i = 0; i < surveyCard.size(); i++) {
	         HashMap<String, String> temp = (HashMap<String, String>) surveyCard.get(i);
	         
	         ArrayList benCalc = new ArrayList<>(temp.values());
	         
	         String bene1 = (String) benCalc.get(temp.size()-2);
	         String[] ben1 = bene1.split("\\^");
	         int seq = Integer.valueOf(String.valueOf(benCalc.get(temp.size()-1)));
	         
	         
	         
	         if (ben1[1].equals("0")) {
	            calcBen1 = benAvg - Integer.parseInt(ben1[2]);
	         } else {
	            calcBen1 = (int) (benAvg - (benAvg * (Double.parseDouble(ben1[2])/100)));
	         }

	         seqBen1.put(seq, calcBen1);
	      }
	      seqBen1Sort.putAll(seqBen1);
	      
	      Set<Integer> seqSet = seqBen1Sort.keySet();
	      Iterator itr = seqSet.iterator();
	      while (itr.hasNext()) {
	         int seq = (int) itr.next();
	         sortBen1Res.add(seq);
	      }
	      
	      //2����
	      HashMap<Integer, Integer> seqBen2 = new HashMap<Integer, Integer>();
	      ValueComparator bvc2 = new ValueComparator(seqBen2);
	      TreeMap<Integer, Integer> seqBen2Sort = new TreeMap<Integer, Integer>(bvc2);
	      ArrayList sortBen2Res = new ArrayList<>();

	      BenAvg ba2 = new BenAvg(prefer2);
	      int ben2Avg = ba.getBenAvg();
	      int calcBen2 = 0;
	      
	      for (int i = 0; i < surveyCard.size(); i++) {
	         HashMap<String, String> temp = (HashMap<String, String>) surveyCard.get(i);
	         
	         ArrayList benCalc2 = new ArrayList<>(temp.values());
	         
	         String bene2 = (String) benCalc2.get(temp.size()-3);
	         String[] ben2 = bene2.split("\\^");
	         int seq = Integer.valueOf(String.valueOf(benCalc2.get(temp.size()-1)));

	         if (ben2[1].equals("0")) {
	            calcBen2 = benAvg - Integer.parseInt(ben2[2]);
	         } else {
	            calcBen2 = (int) (benAvg - (benAvg * (Double.parseDouble(ben2[2])/100)));
	         }

	         seqBen2.put(seq, calcBen2);
	      }
	      seqBen2Sort.putAll(seqBen2);
	      
	      
	      
	      Set<Integer> seqSet2 = seqBen2Sort.keySet();
	      Iterator itr2 = seqSet2.iterator();
	      ArrayList seqAr = new ArrayList();
	      while (itr2.hasNext()) {
	         int seq = (int) itr2.next();
	         seqAr.add(seq);
	      }
	      ArrayList ben2SeqTem = new ArrayList();
	      for(int i=0; i<seqAr.size()-1;i++){
	         
	         int a = seqBen2.get(seqAr.get(i));
	         int b = seqBen2.get(seqAr.get(i+1));
	         int c = seqBen1.get(seqAr.get(i));
	         int d = seqBen1.get(seqAr.get(i+1));
	   
	         if(a!=b){
	            ben2SeqTem.add(seqAr.get(i));
	         }else{
	            if(c>b){
	               ben2SeqTem.add(seqAr.get(i));
	            }else{
	               ben2SeqTem.add(seqAr.get(i+1));
	            }
	         }
	      
	      }
	      
	      //3����
	      HashMap<Integer, Integer> seqBen3 = new HashMap<Integer, Integer>();
	      ValueComparator bvc3 = new ValueComparator(seqBen3);
	      TreeMap<Integer, Integer> seqBen3Sort = new TreeMap<Integer, Integer>(bvc3);
	      ArrayList sortBen3Res = new ArrayList<>();

	      BenAvg ba3 = new BenAvg(prefer3);
	      int ben3Avg = ba.getBenAvg();
	      int calcBen3 = 0;
	      
	      for (int i = 0; i < surveyCard.size(); i++) {
	         HashMap<String, String> temp = (HashMap<String, String>) surveyCard.get(i);
	         
	         ArrayList benCalc3 = new ArrayList<>(temp.values());
	         
	         String bene3 = (String) benCalc3.get(temp.size()-4);
	         String[] ben3 = bene3.split("\\^");
	         int seq = Integer.valueOf(String.valueOf(benCalc3.get(temp.size()-1)));
	         
	         
	         
	         if (ben3[1].equals("0")) {
	            calcBen3 = ben3Avg - Integer.parseInt(ben3[2]);
	         } else {
	            calcBen3 = (int) (ben3Avg - (ben3Avg * (Double.parseDouble(ben3[2])/100)));
	         }

	         seqBen3.put(seq, ((calcBen1+calcBen2+calcBen3)/3));
	         
	      }
	      seqBen3Sort.putAll(seqBen3);
	      
	      
	      
	      Set<Integer> seqSet3 = seqBen2Sort.keySet();
	      Iterator itr3 = seqSet3.iterator();
	      ArrayList seqAr2 = new ArrayList();
	      while (itr3.hasNext()) {
	         int seq = (int) itr3.next();
	         seqAr2.add(seq);
	      }
	      ArrayList ben3SeqTem = new ArrayList();
	      for(int i=0; i<seqAr2.size()-1;i++){
	         
	         int a = seqBen3.get(seqAr2.get(i));
	         int b = seqBen3.get(seqAr2.get(i+1));
	         int c = seqBen2.get(seqAr2.get(i));
	         int d = seqBen2.get(seqAr2.get(i+1));
	   
	         if(a!=b){
	            ben3SeqTem.add(seqAr2.get(i));
	         }else{
	            if(c>b){
	               ben3SeqTem.add(seqAr2.get(i));
	            }else{
	               ben3SeqTem.add(seqAr2.get(i+1));
	            }
	         }
	      
	      }
	      return ben3SeqTem;
	   }

	   public ArrayList getSavingSort(ArrayList surveyCard, String prefer1, String prefer2, String prefer3, String prefer4) {
	      HashMap<Integer, Integer> seqBen1 = new HashMap<Integer, Integer>();
	      ValueComparator bvc = new ValueComparator(seqBen1);
	      TreeMap<Integer, Integer> seqBen1Sort = new TreeMap<Integer, Integer>(bvc);
	      ArrayList sortBen1Res = new ArrayList<>();

	      BenAvg ba = new BenAvg(prefer1);
	      int benAvg = ba.getBenAvg();
	      int calcBen1 = 0;
	      

	      //1����
	      for (int i = 0; i < surveyCard.size(); i++) {
	         HashMap<String, String> temp = (HashMap<String, String>) surveyCard.get(i);
	         ArrayList benCalc = new ArrayList<>(temp.values());
	         String bene1 = (String) benCalc.get(temp.size()-2);
	         String[] ben1 = bene1.split("\\^");
	         int seq = Integer.valueOf(String.valueOf(benCalc.get(temp.size()-1)));
	         
	         if (ben1[1].equals("0")) {
	            calcBen1 = benAvg - Integer.parseInt(ben1[2]);
	         } else {
	            calcBen1 = (int) (benAvg - (benAvg * (Double.parseDouble(ben1[2])/100)));
	         }

	         seqBen1.put(seq, calcBen1);
	      }
	      seqBen1Sort.putAll(seqBen1);
	      
	      Set<Integer> seqSet = seqBen1Sort.keySet();
	      Iterator itr = seqSet.iterator();
	      while (itr.hasNext()) {
	         int seq = (int) itr.next();
	         sortBen1Res.add(seq);
	      }
	      
	      //2����
	      HashMap<Integer, Integer> seqBen2 = new HashMap<Integer, Integer>();
	      ValueComparator bvc2 = new ValueComparator(seqBen2);
	      TreeMap<Integer, Integer> seqBen2Sort = new TreeMap<Integer, Integer>(bvc2);
	      ArrayList sortBen2Res = new ArrayList<>();

	      BenAvg ba2 = new BenAvg(prefer2);
	      int ben2Avg = ba.getBenAvg();
	      int calcBen2 = 0;
	      
	      for (int i = 0; i < surveyCard.size(); i++) {
	         HashMap<String, String> temp = (HashMap<String, String>) surveyCard.get(i);
	         
	         ArrayList benCalc = new ArrayList<>(temp.values());
	         
	         String bene2 = (String) benCalc.get(temp.size()-3);
	         String[] ben2 = bene2.split("\\^");
	         int seq = Integer.valueOf(String.valueOf(benCalc.get(temp.size()-1)));
	         
	         

	         if (ben2[1].equals("0")) {
	            calcBen2 = benAvg - Integer.parseInt(ben2[2]);
	         } else {
	            calcBen2 = (int) (benAvg - (benAvg * (Double.parseDouble(ben2[2])/100)));
	         }

	         seqBen2.put(seq, calcBen2);
	      }
	      seqBen2Sort.putAll(seqBen2);
	      
	      
	      
	      Set<Integer> seqSet2 = seqBen2Sort.keySet();
	      Iterator itr2 = seqSet2.iterator();
	      ArrayList seqAr = new ArrayList();
	      while (itr2.hasNext()) {
	         int seq = (int) itr2.next();
	         seqAr.add(seq);
	      }
	      ArrayList ben2SeqTem = new ArrayList();
	      for(int i=0; i<seqAr.size()-1;i++){
	         
	         int a = seqBen2.get(seqAr.get(i));
	         int b = seqBen2.get(seqAr.get(i+1));
	         int c = seqBen1.get(seqAr.get(i));
	         int d = seqBen1.get(seqAr.get(i+1));
	   
	         if(a!=b){
	            ben2SeqTem.add(seqAr.get(i));
	         }else{
	            if(c>b){
	               ben2SeqTem.add(seqAr.get(i));
	            }else{
	               ben2SeqTem.add(seqAr.get(i+1));
	            }
	         }
	      
	      }
	      
	      //3����
	      HashMap<Integer, Integer> seqBen3 = new HashMap<Integer, Integer>();
	      ValueComparator bvc3 = new ValueComparator(seqBen3);
	      TreeMap<Integer, Integer> seqBen3Sort = new TreeMap<Integer, Integer>(bvc3);
	      ArrayList sortBen3Res = new ArrayList<>();

	      BenAvg ba3 = new BenAvg(prefer3);
	      int ben3Avg = ba.getBenAvg();
	      int calcBen3 = 0;
	      
	      for (int i = 0; i < surveyCard.size(); i++) {
	         HashMap<String, String> temp = (HashMap<String, String>) surveyCard.get(i);
	         
	         ArrayList benCalc3 = new ArrayList<>(temp.values());
	         
	         String bene3 = (String) benCalc3.get(temp.size()-4);
	         String[] ben3 = bene3.split("\\^");
	         int seq = Integer.valueOf(String.valueOf(benCalc3.get(temp.size()-1)));
	         if (ben3[1].equals("0")) {
	            calcBen3 = ben3Avg - Integer.parseInt(ben3[2]);
	         } else {
	            calcBen3 = (int) (ben3Avg - (ben3Avg * (Double.parseDouble(ben3[2])/100)));
	         }

	         seqBen3.put(seq, calcBen3);
	         
	      }
	      seqBen3Sort.putAll(seqBen3);
	      
	      
	      
	      Set<Integer> seqSet3 = seqBen2Sort.keySet();
	      Iterator itr3 = seqSet3.iterator();
	      ArrayList seqAr2 = new ArrayList();
	      while (itr3.hasNext()) {
	         int seq = (int) itr3.next();
	         seqAr2.add(seq);
	      }
	      ArrayList ben3SeqTem = new ArrayList();
	      for(int i=0; i<seqAr2.size()-1;i++){
	         
	         int a = seqBen3.get(seqAr2.get(i));
	         int b = seqBen3.get(seqAr2.get(i+1));
	         int c = seqBen2.get(seqAr2.get(i));
	         int d = seqBen2.get(seqAr2.get(i+1));
	   
	         if(a!=b){
	            ben3SeqTem.add(seqAr2.get(i));
	         }else{
	            if(c>b){
	               ben3SeqTem.add(seqAr2.get(i));
	            }else{
	               ben3SeqTem.add(seqAr2.get(i+1));
	            }
	         }
	      
	      }
	      
	      //4����
	   
	            HashMap<Integer, Integer> seqBen4 = new HashMap<Integer, Integer>();
	            ValueComparator bvc4 = new ValueComparator(seqBen4);
	            TreeMap<Integer, Integer> seqBen4Sort = new TreeMap<Integer, Integer>(bvc4);
	            ArrayList sortBen4Res = new ArrayList<>();

	            BenAvg ba4 = new BenAvg(prefer4);
	            int ben4Avg = ba.getBenAvg();
	            int calcBen4 = 0;
	            for (int i = 0; i < surveyCard.size(); i++) {
	               HashMap<String, String> temp = (HashMap<String, String>) surveyCard.get(i);
	               
	               ArrayList benCalc4 = new ArrayList<>(temp.values());
	               
	               String bene4 = (String) benCalc4.get(temp.size()-5);
	               String[] ben4 = bene4.split("\\^");
	               int seq = Integer.valueOf(String.valueOf(benCalc4.get(temp.size()-1)));
	               
	               if (ben4[1].equals("0")) {
	                  calcBen4 = ben4Avg - Integer.parseInt(ben4[2]);
	               } else {
	                  calcBen4 = (int) (ben4Avg - (ben4Avg * (Double.parseDouble(ben4[2])/100)));
	               }

	               seqBen4.put(seq, ((calcBen1+calcBen2+calcBen3+calcBen4)/4));
	               
	            }
	            seqBen4Sort.putAll(seqBen4Sort);
	            
	            
	            Set<Integer> seqSet4 = seqBen2Sort.keySet();
	            Iterator itr4 = seqSet4.iterator();
	            ArrayList seqAr3 = new ArrayList();
	            while (itr4.hasNext()) {
	               int seq = (int) itr4.next();
	               seqAr3.add(seq);
	            }
	            ArrayList ben4SeqTem = new ArrayList();
	            for(int i=0; i<seqAr3.size()-1;i++){
	               
	               int a = seqBen4.get(seqAr3.get(i));
	               int b = seqBen4.get(seqAr3.get(i+1));
	               int c = seqBen3.get(seqAr3.get(i));
	               int d = seqBen3.get(seqAr3.get(i+1));
	         
	               if(a!=b){
	                  ben4SeqTem.add(seqAr3.get(i));
	               }else{
	                  if(c>b){
	                     ben4SeqTem.add(seqAr3.get(i));
	                  }else{
	                     ben4SeqTem.add(seqAr3.get(i+1));
	                  }
	               }
	            
	            }
	      return ben4SeqTem;
	   }
}
