package cameo.biz;

import java.util.HashMap;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import cameo.util.*;
import cameo.dao.*;
import cameo.entity.*;

@Service("e_boardService")
public class E_BoardManager {

	private E_BoardDAO e_boardDAO;
	
	@Autowired
	public E_BoardManager(E_BoardDAO e_boardDAO){
		super();
		this.e_boardDAO=e_boardDAO;
	}
	
	public List<Card_Benefit> getBoardType(){//E_BoardTypeDTO->Card_Benefit
		
		return e_boardDAO.getBoardType();
	}

	public List<Card_Benefit> getCardList(int btype){//E_BoardTypeDTO->Card_Benefit
		
		return e_boardDAO.getCardList(btype);
	}
	
	public int writeArticle(E_BoardDTO e_boardDTO) {
		return e_boardDAO.writeArticle(e_boardDTO);
	}

	public E_BoardDTO getArticle(int seq, int func) {
		if (func == 0){
			e_boardDAO.updatHit(seq);
		}
		E_BoardDTO e_boardDTO = e_boardDAO.getArticle(seq);		
		return e_boardDTO;
	}

	public List<E_BoardDTO> getList(int btype, int pg, String key, String word) {
		int end = pg * PageSize.BOARD_LIST_SIZE;
		int start = end - PageSize.BOARD_LIST_SIZE;

		HashMap<String, Object> map = new HashMap<String, Object>();
		map.put("btype", btype);
		map.put("end", end);
		map.put("start",start);
		map.put("key", key);
		map.put("word", word);
		return e_boardDAO.getList(map);
	}

	public PageNavi getPageNavi(int btype, int pg, String key, String word) {
		PageNavi pageNavi = new PageNavi();
		
		HashMap<String, Object> map = new HashMap<String, Object>();
		map.put("btype", btype);
		map.put("key", key);
		map.put("word", word);
		
		int totalArticle = e_boardDAO.getTotalArticleCount(map);
		pageNavi.setTotalArticle(totalArticle);
		int listSize = 0;
		listSize = PageSize.BOARD_LIST_SIZE;
		int totalPage = (totalArticle + (listSize - 1)) / listSize;
		pageNavi.setTotalPage(totalPage);
		pageNavi.setPageNo(pg);
		pageNavi.setNowFirst(pg <= PageSize.PAGE_SIZE);
		pageNavi.setNowEnd((((totalPage - 1) / PageSize.PAGE_SIZE) * PageSize.PAGE_SIZE + 1) <= pg ? true : false);
		int newArticleCount = e_boardDAO.getNewArticleCount(btype);
		pageNavi.setNewArticleCount(newArticleCount);
		return pageNavi;
	}

	public int replyArticle(E_BoardDTO e_boardDTO) {
		return e_boardDAO.replyArticle(e_boardDTO);
	}

	public int modifyArticle(E_BoardDTO e_boardDTO) {

		return e_boardDAO.modifyArticle(e_boardDTO);
	}

	public int deleteArticle(int seq) {

		return e_boardDAO.deleteArticle(seq);
	}

}
