package cameo.entity;

import java.sql.Date;

public class Survey {
	private String USER_ID, FEELIMIT, INCOME, SAVING, PREFER1, PREFER2, PREFER3, PREFER4;
	private String LOCATION, GENDER, AGEGROUP, T_Marriage, T_Child;
	private int COL, CARDRATE, MARRIAGE, CHILD;
	private Date SURVEYDATE;
	
	public Survey() {
		super();
		// TODO Auto-generated constructor stub
	}
//�����ϰų� �޾ƿö�.
	public Survey(String user_ID, String feeLimit, String income, String saving, String prefer1, String prefer2,
			String prefer3, String prefer4, String locaion, String gender, String ageGroup, int col, int cardRate,
			int marriage, int child) {
		USER_ID = user_ID;
		FEELIMIT = feeLimit;
		INCOME = income;
		SAVING = saving;
		PREFER1 = prefer1;
		PREFER2 = prefer2;
		PREFER3 = prefer3;
		PREFER4 = prefer4;
		LOCATION = locaion;
		GENDER = gender;
		AGEGROUP = ageGroup;
		COL = col;
		CARDRATE = cardRate;
		MARRIAGE = marriage;
		CHILD = child;
		
	}
//input �Ҷ�.
	public Survey(String user_ID, String feeLimit, String income, String saving, String prefer1, String prefer2,
			String prefer3, String prefer4, String locaion, String gender, String ageGroup, int cardRate, int marriage,
			int child) {
		USER_ID = user_ID;
		FEELIMIT = feeLimit;
		INCOME = income;
		SAVING = saving;
		PREFER1 = prefer1;
		PREFER2 = prefer2;
		PREFER3 = prefer3;
		PREFER4 = prefer4;
		LOCATION = locaion;
		GENDER = gender;
		AGEGROUP = ageGroup;
		CARDRATE = cardRate;
		MARRIAGE = marriage;
		CHILD = child;
	}

	public Date getSurveyDate() {
		return SURVEYDATE;
	}
	public void setSurveyDate(Date surveyDate) {
		SURVEYDATE = surveyDate;
	}
	public String getUser_ID() {
		return USER_ID;
	}

	public void setUser_ID(String user_ID) {
		USER_ID = user_ID;
	}

	public String getFeeLimit() {
		return FEELIMIT;
	}

	public void setFeeLimit(String feeLimit) {
		FEELIMIT = feeLimit;
	}

	public String getIncome() {
		return INCOME;
	}

	public void setIncome(String income) {
		INCOME = income;
	}

	public String getSaving() {
		return SAVING;
	}

	public void setSaving(String saving) {
		SAVING = saving;
	}

	public String getPrefer1() {
		return PREFER1;
	}

	public void setPrefer1(String prefer1) {
		PREFER1 = prefer1;
	}

	public String getPrefer2() {
		return PREFER2;
	}

	public void setPrefer2(String prefer2) {
		PREFER2 = prefer2;
	}

	public String getPrefer3() {
		return PREFER3;
	}

	public void setPrefer3(String prefer3) {
		PREFER3 = prefer3;
	}

	public String getPrefer4() {
		return PREFER4;
	}

	public void setPrefer4(String prefer4) {
		PREFER4 = prefer4;
	}

	public String getLocaion() {
		return LOCATION;
	}

	public void setLocaion(String locaion) {
		LOCATION = locaion;
	}

	public String getGender() {
		return GENDER;
	}

	public void setGender(String gender) {
		GENDER = gender;
	}

	public String getAgeGroup() {
		return AGEGROUP;
	}

	public void setAgeGroup(String ageGroup) {
		AGEGROUP = ageGroup;
	}

	public int getCol() {
		return COL;
	}

	public void setCol(int col) {
		COL = col;
	}

	public int getCardRate() {
		return CARDRATE;
	}

	public void setCardRate(int cardRate) {
		CARDRATE = cardRate;
	}

	public int getMarriage() {
		return MARRIAGE;
	}

	public void setMarriage(int marriage) {
		MARRIAGE = marriage;
	}

	public int getChild() {
		return CHILD;
	}

	public void setChild(int child) {
		CHILD = child;
	}
	
}
