package cameo.entity;

public class E_BoardDTO{
	
	public int getBoard_Seq() {
		return board_Seq;
	}
	public void setBoard_Seq(int board_Seq) {
		this.board_Seq = board_Seq;
	}
	public String getUser_ID() {
		return user_ID;
	}
	public void setUser_ID(String user_ID) {
		this.user_ID = user_ID;
	}
	public String getBoard_Text() {
		return board_Text;
	}
	public void setBoard_Text(String board_Text) {
		this.board_Text = board_Text;
	}
	public String getBoard_A_Date() {
		return board_A_Date;
	}
	public void setBoard_A_Date(String board_A_Date) {
		this.board_A_Date = board_A_Date;
	}
	public int getBtype() {
		return btype;
	}
	public void setBtype(int btype) {
		this.btype = btype;
	}
	public int getBoard_Ref() {
		return board_Ref;
	}
	public void setBoard_Ref(int board_Ref) {
		this.board_Ref = board_Ref;
	}
	public int getBoard_Step() {
		return board_Step;
	}
	public void setBoard_Step(int board_Step) {
		this.board_Step = board_Step;
	}
	public int getBoard_Lev() {
		return board_Lev;
	}
	public void setBoard_Lev(int board_Lev) {
		this.board_Lev = board_Lev;
	}
	public int getBoard_Pseq() {
		return board_Pseq;
	}
	public void setBoard_Pseq(int board_Pseq) {
		this.board_Pseq = board_Pseq;
	}
	public int getBoard_Reply() {
		return board_Reply;
	}
	public void setBoard_Reply(int board_Reply) {
		this.board_Reply = board_Reply;
	}
	private int board_Seq;
	private String user_ID;
	private String board_Text;
	private String board_A_Date;
	private int btype;
	
	private int board_Ref;
	private int board_Step;
	private int board_Lev;
	private int board_Pseq;
	private int board_Reply;
	
	

}
