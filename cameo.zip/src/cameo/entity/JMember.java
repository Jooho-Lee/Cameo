package cameo.entity;

public class JMember {
	private String USER_NAME, USER_ID, USER_PW, USER_IMAGE, USER_TEL,
		USER_EMAIL, USER_BIRTH, USER_GENDER, LAST_ACCESS,USE_YN;
	private int ACCESS_COUNT;
	
	public JMember() {
		super();
	}

	public JMember(String uSER_ID, String uSER_NAME, String uSER_PW, String uSER_IMAGE, String uSER_TEL,
			String uSER_EMAIL, String uSER_BIRTH, String uSER_GENDER) {
		super();
		USER_NAME = uSER_NAME;
		USER_ID = uSER_ID;
		USER_PW = uSER_PW;
		USER_IMAGE = uSER_IMAGE;
		USER_TEL = uSER_TEL;
		USER_EMAIL = uSER_EMAIL;
		USER_BIRTH = uSER_BIRTH;
		USER_GENDER = uSER_GENDER;
	}

	@Override
	public String toString() {
		return "JMember [USER_NAME=" + USER_NAME + ", USER_ID=" + USER_ID + ", USER_PW=" + USER_PW + ", USER_IMAGE="
				+ USER_IMAGE + ", USER_TEL=" + USER_TEL + ", USER_EMAIL=" + USER_EMAIL + ", USER_BIRTH=" + USER_BIRTH
				+ ", USER_GENDER=" + USER_GENDER + "]";
	}

	public int getACCESS_COUNT() {
		return ACCESS_COUNT;
	}

	public void setACCESS_COUNT(int aCCESS_COUNT) {
		ACCESS_COUNT = aCCESS_COUNT;
	}

	public String getLAST_ACCESS() {
		return LAST_ACCESS;
	}

	public void setLAST_ACCESS(String lAST_ACCESS) {
		LAST_ACCESS = lAST_ACCESS;
	}

	public String getUSE_YN() {
		return USE_YN;
	}

	public void setUSE_YN(String uSE_YN) {
		USE_YN = uSE_YN;
	}

	public String getUSER_NAME() {
		return USER_NAME;
	}

	public void setUSER_NAME(String uSER_NAME) {
		USER_NAME = uSER_NAME;
	}

	public String getUSER_ID() {
		return USER_ID;
	}

	public void setUSER_ID(String uSER_ID) {
		USER_ID = uSER_ID;
	}

	public String getUSER_PW() {
		return USER_PW;
	}

	public void setUSER_PW(String uSER_PW) {
		USER_PW = uSER_PW;
	}

	public String getUSER_IMAGE() {
		return USER_IMAGE;
	}

	public void setUSER_IMAGE(String uSER_IMAGE) {
		USER_IMAGE = uSER_IMAGE;
	}

	public String getUSER_TEL() {
		return USER_TEL;
	}

	public void setUSER_TEL(String uSER_TEL) {
		USER_TEL = uSER_TEL;
	}

	public String getUSER_EMAIL() {
		return USER_EMAIL;
	}

	public void setUSER_EMAIL(String uSER_EMAIL) {
		USER_EMAIL = uSER_EMAIL;
	}

	public String getUSER_BIRTH() {
		return USER_BIRTH;
	}

	public void setUSER_BIRTH(String uSER_BIRTH) {
		USER_BIRTH = uSER_BIRTH;
	}

	public String getUSER_GENDER() {
		return USER_GENDER;
	}

	public void setUSER_GENDER(String uSER_GENDER) {
		USER_GENDER = uSER_GENDER;
	}

}