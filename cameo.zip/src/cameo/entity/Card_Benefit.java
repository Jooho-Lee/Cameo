package cameo.entity;

public class Card_Benefit {
	private int Card_Seq;
	private String Card_Name;
	private String Card_Type;
	private String Card_Corp;
	private String Card_Image;
	private int AnnualFee;
	
	private int Ben_Seq;
	private int Usage_Result;
	private String Ben1, Ben2, Ben3, Ben4, Ben5, Ben6, Ben7, Ben8, Ben9, Ben10
	, Ben11, Ben12, Ben13, Ben14, Ben15, Ben16, Ben17, Ben18, Ben19, Ben20;

	/******************************************************************************************************************/
	public Card_Benefit() {
		
	}

	/******************************************************************************************************************/
	public Card_Benefit(int card_Seq, String card_Name, String card_Type, String card_Corp, String card_Image,
			int annualFee) {
		super();
		Card_Seq = card_Seq;
		Card_Name = card_Name;
		Card_Type = card_Type;
		Card_Corp = card_Corp;
		Card_Image = card_Image;
		AnnualFee = annualFee;
	}
	
	/******************************************************************************************************************/
	public Card_Benefit(String card_Name, String card_Type, String card_Corp, String card_Image, int annualFee) {
		super();
		Card_Name = card_Name;
		Card_Type = card_Type;
		Card_Corp = card_Corp;
		Card_Image = card_Image;
		AnnualFee = annualFee;
	}
	
	/******************************************************************************************************************/
	public Card_Benefit(int usage_Result, String ben1, String ben2, String ben3, String ben4, String ben5, String ben6,
			String ben7, String ben8, String ben9, String ben10, String ben11, String ben12, String ben13, String ben14,
			String ben15, String ben16, String ben17, String ben18, String ben19, String ben20) {
		super();
		Usage_Result = usage_Result;
		Ben1 = ben1;
		Ben2 = ben2;
		Ben3 = ben3;
		Ben4 = ben4;
		Ben5 = ben5;
		Ben6 = ben6;
		Ben7 = ben7;
		Ben8 = ben8;
		Ben9 = ben9;
		Ben10 = ben10;
		Ben11 = ben11;
		Ben12 = ben12;
		Ben13 = ben13;
		Ben14 = ben14;
		Ben15 = ben15;
		Ben16 = ben16;
		Ben17 = ben17;
		Ben18 = ben18;
		Ben19 = ben19;
		Ben20 = ben20;
	}

	/******************************************************************************************************************/
	public Card_Benefit(int ben_Seq, int usage_Result, String ben1, String ben2, String ben3, String ben4, String ben5,
			String ben6, String ben7, String ben8, String ben9, String ben10, String ben11, String ben12, String ben13,
			String ben14, String ben15, String ben16, String ben17, String ben18, String ben19, String ben20) {
		super();
		Ben_Seq = ben_Seq;
		Usage_Result = usage_Result;
		Ben1 = ben1;
		Ben2 = ben2;
		Ben3 = ben3;
		Ben4 = ben4;
		Ben5 = ben5;
		Ben6 = ben6;
		Ben7 = ben7;
		Ben8 = ben8;
		Ben9 = ben9;
		Ben10 = ben10;
		Ben11 = ben11;
		Ben12 = ben12;
		Ben13 = ben13;
		Ben14 = ben14;
		Ben15 = ben15;
		Ben16 = ben16;
		Ben17 = ben17;
		Ben18 = ben18;
		Ben19 = ben19;
		Ben20 = ben20;
	}

	/******************************************************************************************************************/
	public int getCard_Seq() {
		return Card_Seq;
	}

	public void setCard_Seq(int card_Seq) {
		Card_Seq = card_Seq;
	}

	public String getCard_Name() {
		return Card_Name;
	}

	public void setCard_Name(String card_Name) {
		Card_Name = card_Name;
	}

	public String getCard_Type() {
		return Card_Type;
	}

	public void setCard_Type(String card_Type) {
		Card_Type = card_Type;
	}

	public String getCard_Corp() {
		return Card_Corp;
	}

	public void setCard_Corp(String card_Corp) {
		Card_Corp = card_Corp;
	}

	public String getCard_Image() {
		return Card_Image;
	}

	public void setCard_Image(String card_Image) {
		Card_Image = card_Image;
	}

	public int getAnnualFee() {
		return AnnualFee;
	}

	public void setAnnualFee(int annualFee) {
		AnnualFee = annualFee;
	}

	public int getBen_Seq() {
		return Ben_Seq;
	}

	public void setBen_Seq(int ben_Seq) {
		Ben_Seq = ben_Seq;
	}

	public int getUsage_Result() {
		return Usage_Result;
	}

	public void setUsage_Result(int usage_Result) {
		Usage_Result = usage_Result;
	}

	public String getBen1() {
		return Ben1;
	}

	public void setBen1(String ben1) {
		Ben1 = ben1;
	}

	public String getBen2() {
		return Ben2;
	}

	public void setBen2(String ben2) {
		Ben2 = ben2;
	}

	public String getBen3() {
		return Ben3;
	}

	public void setBen3(String ben3) {
		Ben3 = ben3;
	}

	public String getBen4() {
		return Ben4;
	}

	public void setBen4(String ben4) {
		Ben4 = ben4;
	}

	public String getBen5() {
		return Ben5;
	}

	public void setBen5(String ben5) {
		Ben5 = ben5;
	}

	public String getBen6() {
		return Ben6;
	}

	public void setBen6(String ben6) {
		Ben6 = ben6;
	}

	public String getBen7() {
		return Ben7;
	}

	public void setBen7(String ben7) {
		Ben7 = ben7;
	}

	public String getBen8() {
		return Ben8;
	}

	public void setBen8(String ben8) {
		Ben8 = ben8;
	}

	public String getBen9() {
		return Ben9;
	}

	public void setBen9(String ben9) {
		Ben9 = ben9;
	}

	public String getBen10() {
		return Ben10;
	}

	public void setBen10(String ben10) {
		Ben10 = ben10;
	}

	public String getBen11() {
		return Ben11;
	}

	public void setBen11(String ben11) {
		Ben11 = ben11;
	}

	public String getBen12() {
		return Ben12;
	}

	public void setBen12(String ben12) {
		Ben12 = ben12;
	}

	public String getBen13() {
		return Ben13;
	}

	public void setBen13(String ben13) {
		Ben13 = ben13;
	}

	public String getBen14() {
		return Ben14;
	}

	public void setBen14(String ben14) {
		Ben14 = ben14;
	}

	public String getBen15() {
		return Ben15;
	}

	public void setBen15(String ben15) {
		Ben15 = ben15;
	}

	public String getBen16() {
		return Ben16;
	}

	public void setBen16(String ben16) {
		Ben16 = ben16;
	}

	public String getBen17() {
		return Ben17;
	}

	public void setBen17(String ben17) {
		Ben17 = ben17;
	}

	public String getBen18() {
		return Ben18;
	}

	public void setBen18(String ben18) {
		Ben18 = ben18;
	}

	public String getBen19() {
		return Ben19;
	}

	public void setBen19(String ben19) {
		Ben19 = ben19;
	}

	public String getBen20() {
		return Ben20;
	}

	public void setBen20(String ben20) {
		Ben20 = ben20;
	}

	public void setBenefit(Card_Benefit benefit) {
		// TODO Auto-generated method stub
		
	}
	
	
	
}
