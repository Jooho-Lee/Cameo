package cameo.entity;

import javax.validation.constraints.NotNull;

public class Notice {
	@NotNull
	private int Notice_Seq;
	private String Notice_Text;
	
	private String Notice_C_Date;
	private String Notice_A_Date;
	
	public Notice() {
		super();
	}

	public Notice(int notice_Seq, String notice_Text, String notice_C_Date, String notice_A_Date) {
		super();
		Notice_Seq = notice_Seq;
		Notice_Text = notice_Text;
		Notice_C_Date = notice_C_Date;
		Notice_A_Date = notice_A_Date;
	}

	public Notice(String notice_Text, String notice_C_Date, String notice_A_Date) {
		super();
		Notice_Text = notice_Text;
		Notice_C_Date = notice_C_Date;
		Notice_A_Date = notice_A_Date;
	}
	
	public void setNotice(Notice notice) {
		// TODO Auto-generated method stub
		
	}

	public int getNotice_Seq() {
		return Notice_Seq;
	}

	public void setNotice_Seq(int notice_Seq) {
		Notice_Seq = notice_Seq;
	}

	public String getNotice_Text() {
		return Notice_Text;
	}

	public void setNotice_Text(String notice_Text) {
		Notice_Text = notice_Text;
	}

	public String getNotice_C_Date() {
		return Notice_C_Date;
	}

	public void setNotice_C_Date(String notice_C_Date) {
		Notice_C_Date = notice_C_Date;
	}

	public String getNotice_A_Date() {
		return Notice_A_Date;
	}

	public void setNotice_A_Date(String notice_A_Date) {
		Notice_A_Date = notice_A_Date;
	}
	
	
	
}
